//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.google.gson.Gson;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import nn.*;


/**
 * Servlet implementation class ServeletNNStart
 */
public class ServeletNNStart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletNNStart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		NeuronskaMreza nn = (NeuronskaMreza) request.getSession().getAttribute("nn");
	    // Priprema za čitanje podataka iz zahteva
	    JSONParser parser = new JSONParser();
	    JSONArray jsonArray = null;
	    try {
	        jsonArray = (JSONArray) parser.parse(request.getReader());
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
	    
	    double[][] ulaz;
	    double[] red = new double[jsonArray.size()];

	    // Obrada niza double vrednosti
	    if (jsonArray != null) {
	        for (int i = 0; i < jsonArray.size();i++) {
	            String numberString = (String) jsonArray.get(i);
	            red[i] = Double.parseDouble(numberString);       	        	
	            //red[i] = (double) jsonArray.get(i);
	        }
	    }
	    ulaz = new double[1][red.length];
	    ulaz[0] = red;
	    // Obrada zahteva i generisanje double niza
	    double[][] izlaz = nn.realanIzlaz(ulaz); 
	    // Konvertovanje niza u JSON format koristeći GSON biblioteku
	    Gson gson = new Gson();
	    String json = gson.toJson(izlaz);

	    // Slanje JSON niza nazad kao odgovor
	    response.getWriter().write(json);
	}

}
