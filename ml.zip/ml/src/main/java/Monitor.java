//package nn;


import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

// KlasaMonitor
public class Monitor extends JToolBar {
    static JEditorPane  t ;
    static String tekst = "";
    static String tekst1="-";

    JScrollPane editorScrollPane;

    public Monitor(){
		super("Monitor");
        t = new JEditorPane();
        t.setContentType("text/plain");

        editorScrollPane = new JScrollPane(t);
        //editorScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		editorScrollPane.setPreferredSize(new Dimension(250, 150));
        //editorScrollPane.setMinimumSize(new Dimension(10, 10));

		Font font = new Font("Verdana", Font.BOLD, 14);
        t.setFont(font);

        this.add(editorScrollPane);
   }

    public static void setMonitor(String t1){
          tekst = tekst + t1 + "\n" ;
          t.setText(tekst);
          tekst1 = tekst;
    }


    public static void izbrisi(){
	          tekst = "";
    }
}

