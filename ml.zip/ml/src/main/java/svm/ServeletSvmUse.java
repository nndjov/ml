package svm;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import svm.libsvm.svm_model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.*;
import org.json.simple.parser.*;




/**
 * Servlet implementation class ServeletSvmUse
 */
public class ServeletSvmUse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletSvmUse() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		// Logika za generisanje matrica
	    SVM svm = (SVM) request.getSession().getAttribute("svm");
		svm_model model = (svm_model) request.getSession().getAttribute("model");

	////////////////////////////////////////    
			double[][] x = svm.dataset1.node_values();
			double[] y = svm.dataset1.node_class_labels();

			ArrayList<double[]> lista1 = new ArrayList<>();
	        ArrayList<double[]> lista2 = new ArrayList<>();
	        double xMin = x[0][0];
	        double xMax = x[0][0];
	        double yMin = x[0][1];
	        double yMax = x[0][1];
	        for(int i = 0; i<x.length; i++){
				if(y[i] == 1){
					lista1.add(x[i]);
				} else{
					lista2.add(x[i]);
				}
				//naci min i max za x i y osu
				if(xMin>x[i][0])
				   xMin = x[i][0];
				if(xMax<x[i][0])
				   xMax = x[i][0];

				if(yMin>x[i][1])
				   yMin = x[i][1];
				if(yMax<x[i][1])
				   yMax = x[i][1];
			}
	        Integer sirina =  500;
	        Integer visina  =  400;

			double xKorak = (xMax-xMin)/sirina;
			double yKorak = (yMax-yMin)/visina;	
       
			ArrayList<double[]> lista01 = new ArrayList<>();
	        ArrayList<double[]> lista02 = new ArrayList<>();
	        xMin = xMin - (xMax-xMin)/7;
	        xMax = xMax + (xMax-xMin)/7;
	        yMin = yMin - (yMax-yMin)/7;
	        yMax = yMax + (yMax-yMin)/7;
			for(double i = xMin; i < xMax; i+=xKorak){
				for(double j = yMin; j < yMax; j+=yKorak){
					int[] indeksi={1,2};
					double[] vrednosti = {i, j};
	                double klasa = svm.klasa(indeksi, vrednosti, model);
	                if(klasa == 1.0){
						lista01.add(vrednosti);
					} else {
						lista02.add(vrednosti);
					}
				}
			}
			double[][] niz011 = lista01.toArray(new double[lista01.size()][2]);
			double[][] niz021 = lista02.toArray(new double[lista02.size()][2]);
			double[][] niz01 = new double[niz011.length][niz011[0].length];
			for(int i = 0; i<niz01.length; i++){
				for(int j = 0; j<niz01[0].length; j++){
					niz01[i][j] = niz011[i][j];
				}
			}
			double[][] niz02 = new double[niz021.length][niz021[0].length];
			for(int i = 0; i<niz02.length; i++){
				for(int j = 0; j<niz02[0].length; j++){
					niz02[i][j] = niz021[i][j];
				}
			}			

	//Prihvatanje matrice iz AJAXA
			   StringBuilder sb = new StringBuilder();
			    String s;
			    while ((s = request.getReader().readLine()) != null) {
			        sb.append(s);
			    }
			    JSONParser parser = new JSONParser();
			    JSONObject jsonObj=null;
				try {
					jsonObj = (JSONObject) parser.parse(sb.toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    JSONArray jsonMatrica = (JSONArray) jsonObj.get("matrica");

			    // Konvertujte JSONArray u matricu
			    double[][] matricaUse = new double[jsonMatrica.size()][];
			    for (int i = 0; i < jsonMatrica.size(); i++) {
			        JSONArray red = (JSONArray) jsonMatrica.get(i);
			        matricaUse[i] = new double[red.size()];
			        for (int j = 0; j < red.size(); j++) {
			        	matricaUse[i][j] = (double) red.get(j);
			        }
			    }	
	//NOVO
	///Odredjivanje klasa
			    
			ArrayList<String[]> listaUse = new ArrayList<>();      
	       //String rezUse =  "KLASE\n";
	        //rezUse +=  "---------------\n";
			for(int i = 0; i < matricaUse.length; i++){
				//for(int j = 0; j < matricaUse[0].length; j++){
					int[] indeksi={1,2};
					double[] vrednosti = {matricaUse[i][0], matricaUse[i][1]};
	                double klasa = svm.klasa(indeksi, vrednosti, model);
	                String ss[] = new String[3];
	                if(klasa == 1.0){
	                	ss[0] = ""+ matricaUse[i][0];
	                	ss[1] = ""+ matricaUse[i][1];
	                	ss[2] = "Class 1";
	                	//rezUse += "["+matricaUse[i][0]+", "+matricaUse[i][1]+"] class 1\n";
					} else {
	                	ss[0] = ""+ matricaUse[i][0];
	                	ss[1] = ""+ matricaUse[i][1];
	                	ss[2] = "Class 2";						
						//rezUse += "["+matricaUse[i][0]+", "+matricaUse[i][1]+"] class 2\n";
					}
	                listaUse.add(ss);
				//}
			}
			
			String[][] nizUse = listaUse.toArray(new String[listaUse.size()][3]);
	
	//////

	    // Kreiranje JSON objekta za slanje nazad
	    JSONObject odgovor = new JSONObject();
	    odgovor.put("matrica3", niz01);
	    odgovor.put("matrica4", niz02);
	    odgovor.put("rezUse", nizUse);
	   // odgovor.put("rezUse", rezUse);

	    // Slanje odgovora
	    response.getWriter().print(odgovor.toJSONString());
	    	    
//////////
	    
	}
}
