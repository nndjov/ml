package svm.libsvm;

public class Rezultat {
	public static String rez="";

}
