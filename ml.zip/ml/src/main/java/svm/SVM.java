package svm;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import svm.libsvm.*;

public class SVM {
	int TP;
	int FP;
	int FN;
	int TN;
	public Dataset dataset;
	public Dataset dataset1;
	//public void ucitajPodatke(String Filename1, Dataset dataset, Dataset dataset1 ){
	public void ucitajPodatke(LinkedList<String> listaPodataka, int granica ){
		//dataset - trening podaci
		//dataset1 - test podaci
		Dataset dataset = new Dataset(); 
		Dataset dataset1= new Dataset(); ;
		//LinkedList<String> listaPodataka = new LinkedList<String>();//
/*		
		try{
		//int i=0;
			FileReader fr1 = new FileReader(Filename1);
			BufferedReader br1 = new BufferedReader(fr1);
			for(String line1 = br1.readLine();line1!=null;line1=br1.readLine()){
				listaPodataka.add(line1);
			}
			br1.close();
		}catch(Exception e){
			e.printStackTrace();
		}
*/		
        // Promesaj podatke
		//Collections.shuffle(listaPodataka);

		int record_size = listaPodataka.size();
		System.out.println("listaPodataka Size "+record_size);

		//Trening podaci
		//int granica = 4*(listaPodataka.size()/5);
        System.out.println("Velicina trening podataka = " + granica);
		double node_values[][] = new double[granica][];
		int node_indexes[][] = new int[granica][];
		double node_class_labels [] = new double[granica];//za binarno 1 ili 0

		double node_values1[][] = new double[record_size-granica][];
		int node_indexes1[][] = new int[record_size-granica][];
		double node_class_labels1[] = new double[record_size-granica];//za binarno 1 ili 0
		System.out.println("Velicina test podataka = " + node_values1.length);

		for(int i=0;i< granica;i++){
			try{
				String [] data1 = listaPodataka.get(i).split("\\s");
				node_class_labels[i] = Integer.parseInt(data1[0].trim());
				LinkedList<Integer> list_indx = new LinkedList<Integer>();
				LinkedList<Double> list_val = new LinkedList<Double>();
				for(int k=0; k<data1.length;k++){
				String [] tmp_data = data1[k].trim().split(":");
					if(tmp_data.length==2){
						list_indx.add(Integer.parseInt(tmp_data[0].trim()));
						list_val.add(Double.parseDouble(tmp_data[1].trim()));
						//System.out.println("Index  "+tmp_data[0]+" Value "+tmp_data[1]);
					}
				}
				if(list_val.size()>0){
					node_values[i] = new double[list_val.size()];
					node_indexes[i] = new int[list_indx.size()];
				}

				for(int m=0;m<list_val.size();m++){
					node_indexes[i][m] = list_indx.get(m);
					node_values[i][m] = list_val.get(m);
					//System.out.println("List Index value "+list_indx.get(m)+"  <=> List values "+list_val.get(m)+"  list size "+list_indx.size());
				}
			}catch(Exception e){
				e.printStackTrace();
			}
	    }
		    dataset.setNode_valuses(node_values);
			dataset.setNode_indexes(node_indexes);
		    dataset.setNode_class_labels(node_class_labels);
		//}
///////////////
        int kk=0;
		for(int i=granica;i< listaPodataka.size();i++){
			try{
				String [] data1 = listaPodataka.get(i).split("\\s");
				node_class_labels1[kk] = Integer.parseInt(data1[0].trim());
				LinkedList<Integer> list_indx = new LinkedList<Integer>();
				LinkedList<Double> list_val = new LinkedList<Double>();
				for(int k=0; k<data1. length;k++){
				String [] tmp_data = data1[k].trim().split(":");
					if(tmp_data.length==2){
						list_indx.add(Integer.parseInt(tmp_data[0].trim()));
						list_val.add(Double.parseDouble(tmp_data[1].trim()));
						//System.out.println("Index  "+tmp_data[0]+" Value "+tmp_data[1]);
					}
				}
				if(list_val.size()>0){
					node_values1[kk] = new double[list_val.size()];
					node_indexes1[kk] = new int[list_indx.size()];
				}

				for(int m=0;m<list_val.size();m++){
					node_indexes1[kk][m] = list_indx.get(m);
					node_values1[kk][m] = list_val.get(m);
					//System.out.println("List Index value "+list_indx.get(m)+"  <=> List values "+list_val.get(m)+"  list size "+list_indx.size());
				}
				kk++;
			}catch(Exception e){
				e.printStackTrace();
			}
       }
		dataset1.setNode_valuses(node_values1);
		dataset1.setNode_indexes(node_indexes1);
		dataset1.setNode_class_labels(node_class_labels1);

		this.dataset = dataset;
		this.dataset1 = dataset1;

//////////////
	}

	public svm_problem model(Dataset dataset){
		double node_values[][] = dataset.node_values();
		int node_indexes[][] = dataset.node_indexes();
		double node_class_labels[] = dataset.node_class_labels();

		// Pravljenje modela
	   	svm_problem prob = new svm_problem();
	   	int dataCount = dataset.record_size();
	  	prob.y = new double[dataCount];
	   	prob.l = dataCount;
	   	prob.x = new svm_node[dataCount][];
	   	for (int i = 0; i < dataCount; i++){
	   	   prob.y[i] = node_class_labels[i];
		   double[] values = node_values[i];
		   int [] indexes = node_indexes[i];
		   prob.x[i] = new svm_node[values.length];
		   for (int j = 0; j < values.length; j++){
			   svm_node node = new svm_node();
			   node.index = indexes[j];
			   node.value = values[j];
			   prob.x[i][j] = node;
		   }
	   	}

	   	//svm_model model = svm.svm_train(prob, param);
	   	return prob;
	}
/*
	   	param.svm_type = svm_parameter.C_SVC;  int
	   	param.kernel_type = svm_parameter.LINEAR;  int
	   	public int degree;
	   	param.gamma = 0.802;  double
	   	public double coef0;

	   	param.cache_size = 20000; double
	   	param.eps = 0.0001; double
	   	param.C = 100;   double
	   	param.nu = 0.5;   double
	   	param.probability = 1;  int
*/
	public svm_parameter setParametar(int svm_type, int kernel_type, int degree, double gamma, 
			double coef0,
	double cache_size, double eps, double C, double nu, int probability){
		// Definisanje parametara
	   	svm_parameter param = new svm_parameter();
	   	param.svm_type = svm_type;
	   	param.kernel_type = kernel_type;
	   	param.degree = degree;
	   	param.gamma = gamma;   
	   	param.coef0 = coef0;  
	   	param.cache_size = cache_size;
	   	param.eps = eps;
	   	param.C = C;
	   	param.nu = nu;
	   	param.probability = probability;
	   	
	  	
	   	
	   	
	   	
	   	param.eps = eps;
		
/*
	   	param.probability = 1;
	  	//param.gamma = 0.5;
	  	param.gamma = 0.802;
	   	param.nu = 0.5;
	   	//param.nu = 0.1608;
	   	param.C = 100;
	   	param.svm_type = svm_parameter.C_SVC;
	   	//param.svm_type    = svm_parameter.ONE_CLASS;
	   	//param.kernel_type = svm_parameter.RBF;
	   	param.kernel_type = svm_parameter.LINEAR;
	   	param.cache_size = 20000;
	   	//param.eps = 0.001;
	   	param.eps = 0.0001;
*/
	   	return param;
	}

	public svm_model trening(svm_problem prob, svm_parameter param){
		svm_model model = svm.svm_train(prob, param);
		return model;
	}

	//write code to test all instances from given file
	public void testAll(Dataset ds, svm_model model1){
		TP=0;
		FP=0;
		FP=0;
		TN=0;
		double node_values[][] = ds.node_values();
		int node_indexes[][] = 	ds.node_indexes();
		double[] node_class_labels = ds.node_class_labels();
		int record_size = ds.record_size();

		for(int i=0;i<record_size;i++){
			int tmp_indexes[] = node_indexes[i];
			double tmp_values[] = node_values[i];
			test(tmp_indexes,tmp_values, model1, node_class_labels[i]);
		}
	}
	public String testSve(Dataset ds, svm_model model1){
		TP=0;
		FP=0;
		FP=0;
		TN=0;
		String rez = " Prediction   Actual value"+"\n";
			   rez += " -------------------------"+"\n";
		double node_values[][] = ds.node_values();
		int node_indexes[][] = 	ds.node_indexes();
		double[] node_class_labels = ds.node_class_labels();
		int record_size = ds.record_size();

		for(int i=0;i<record_size;i++){
			int tmp_indexes[] = node_indexes[i];
			double tmp_values[] = node_values[i];
			rez += testRez(tmp_indexes,tmp_values, model1, node_class_labels[i])+"\n";
		}
		return rez;
	}	
/*
	public void testAll(String Filename1, svm_model model1){
		TP=0;
		FP=0;
		FP=0;
		TN=0;
		Dataset ds = ucitajPodatke(Filename1);
		double node_values[][] = ds.node_values();
		int node_indexes[][] = 	ds.node_indexes();
		double[] node_class_labels = ds.node_class_labels();
		int record_size = ds.record_size();

		for(int i=0;i<record_size;i++){
			int tmp_indexes[] = node_indexes[i];
			double tmp_values[] = node_values[i];
			test(tmp_indexes,tmp_values, model1, node_class_labels[i]);
		}
	}
*/
	//write the code to test single feature each time by using SVM
	public void test(int [] indexes, double[] values, svm_model model1, double klasa){
	   svm_node[] nodes = new svm_node[values.length];
	   for (int i = 0; i < values.length; i++){
		   svm_node node = new svm_node();
		   node.index = indexes[i];
		   node.value = values[i];
		   nodes[i] = node;
	   }

	   int totalClasses = svm.svm_get_nr_class(model1);
	   int[] labels = new int[totalClasses];
	   svm.svm_get_labels(model1,labels);
	   double[] prob_estimates = new double[totalClasses];
	   double v = svm.svm_predict_probability(model1, nodes, prob_estimates);
	   //for (int i = 0; i < totalClasses; i++){
		//   System.out.print("(" + labels[i] + ":" + prob_estimates[i] + ")");
	   //}
	   System.out.println(" Prediction:" + v + " -- Stvarna vrednost:" + klasa);
	   if(v==1.0 && klasa == 1.0)
	       TP++;
	   if(v==1.0 && klasa == 0.0)
	       FP++;
	   if(v==0.0 && klasa == 1.0)
	       FN++;
	   if(v==0.0 && klasa == 0.0)
	       TN++;
	}
////////
	public String testRez(int [] indexes, double[] values, svm_model model1, double klasa){
		String rez = "";
		   svm_node[] nodes = new svm_node[values.length];
		   for (int i = 0; i < values.length; i++){
			   svm_node node = new svm_node();
			   node.index = indexes[i];
			   node.value = values[i];
			   nodes[i] = node;
		   }

		   int totalClasses = svm.svm_get_nr_class(model1);
		   int[] labels = new int[totalClasses];
		   svm.svm_get_labels(model1,labels);
		   double[] prob_estimates = new double[totalClasses];
		   double v = svm.svm_predict_probability(model1, nodes, prob_estimates);
		   //for (int i = 0; i < totalClasses; i++){
			//   System.out.print("(" + labels[i] + ":" + prob_estimates[i] + ")");
		   //}
		   rez += "    " + v + "          " + klasa+"\n";
		   if(v==1.0 && klasa == 1.0)
		       TP++;
		   if(v==1.0 && klasa == 0.0)
		       FP++;
		   if(v==0.0 && klasa == 1.0)
		       FN++;
		   if(v==0.0 && klasa == 0.0)
		       TN++;
		   
		   return rez;
	}

	public double klasa(int [] indexes, double[] values, svm_model model1){
	   svm_node[] nodes = new svm_node[values.length];
	   for (int i = 0; i < values.length; i++){
		   svm_node node = new svm_node();
		   node.index = indexes[i];
		   node.value = values[i];
		   nodes[i] = node;
	   }

	   int totalClasses = svm.svm_get_nr_class(model1);
	  // int[] labels = new int[totalClasses];
	   //svm.svm_get_labels(model1,labels);

	   double[] prob_estimates = new double[totalClasses];
	   double v = svm.svm_predict_probability(model1, nodes, prob_estimates);

	   return v;

	}

////////


	public String matricaKonfuzije(){
		String s = "";
		s += "Confusion Matrix\n";
		s += "-----------------\n";
		s += TP + "   " + FP+"\n";
		s += FN + "   " + TN +"\n";
		return s;
	}
/*
	public void graf(String naslov, Dataset ds, svm_model model){
		Graf graf = new Graf(naslov, "xOsa", "yOsa");
		graf.setSize(500, 400);
		double[][] x = ds.node_values();
		double[] y = ds.node_class_labels();

		ArrayList<double[]> lista1 = new ArrayList<>();
        ArrayList<double[]> lista2 = new ArrayList<>();
        double xMin = x[0][0];
        double xMax = x[0][0];
        double yMin = x[0][1];
        double yMax = x[0][1];
        for(int i = 0; i<x.length; i++){
			if(y[i] == 1){
				lista1.add(x[i]);
			} else{
				lista2.add(x[i]);
			}
			//naci min i max ya x i y osu
			if(xMin>x[i][0])
			   xMin = x[i][0];
			if(xMax<x[i][0])
			   xMax = x[i][0];

			if(yMin>x[i][1])
			   yMin = x[i][1];
			if(yMax<x[i][1])
			   yMax = x[i][1];
		}
        Integer sirina =  graf.sirina();
        Integer visina  =  graf.visina();
System.out.println("sirina = " + sirina);
		double xKorak = (xMax-xMin)/x.length;
		double yKorak = (yMax-yMin)/x.length;
        if(sirina > x.length){
			xKorak = (xMax-xMin)/sirina;
		}
        if(visina > y.length){
			yKorak = (yMax-yMin)/visina;
		}
		ArrayList<double[]> lista01 = new ArrayList<>();
        ArrayList<double[]> lista02 = new ArrayList<>();
        xMin = xMin - (xMax-xMin)/7;
        xMax = xMax + (xMax-xMin)/7;
        yMin = yMin - (yMax-yMin)/7;
        yMax = yMax + (yMax-yMin)/7;
		for(double i = xMin; i < xMax; i+=xKorak){
			for(double j = yMin; j < yMax; j+=yKorak){
				int[] indeksi={1,2};
				double[] vrednosti = {i, j};
                double klasa = klasa(indeksi, vrednosti, model);
                if(klasa == 1.0){
					lista01.add(vrednosti);
				} else {
					lista02.add(vrednosti);
				}
			}
		}
		double[][] niz01 = lista01.toArray(new double[lista01.size()][2]);
		double[][] niz02 = lista02.toArray(new double[lista02.size()][2]);

		double[][] niz1 = lista1.toArray(new double[lista1.size()][2]);
		double[][] niz2 = lista2.toArray(new double[lista2.size()][2]);



        graf.dodajPodatke("1", niz1);
        graf.dodajPodatke("0", niz2);
        graf.dodajPodatke("", niz01);
        graf.dodajPodatke(" ", niz02);
        graf.prikazi();
	}
*/
	public static void main(String[] args) {
		/*
		SVM svm = new SVM();
		Dataset ds = new Dataset();
		Dataset ds1= new Dataset();
		svm.ucitajPodatke("podaci.txt", ds, ds1);
		svm_model model = svm.model(ds);
		svm.testAll(ds, model);
		*/
	}
}