package svm;

import java.io.*;
import java.util.*;

public class Dataset{
	private double[][] node_values;
	private int[][] node_indexes;
	private double[] node_class_labels;

	private int record_size;

	public void setNode_valuses(double node_values[][]){
		this.node_values = node_values;
	}
	public void setNode_indexes(int node_indexes[][]){
		this.node_indexes = node_indexes;
	}
	public void setNode_class_labels(double node_class_labels[]){
		this.node_class_labels = node_class_labels;
	}

	public double[][] node_values(){
		return node_values;
	}
	public int[][] node_indexes(){
		return node_indexes;
	}
	public double[] node_class_labels(){
		return node_class_labels;
	}
	public int record_size(){
		return node_values.length;
	}

	public void prikazi(){
		System.out.println("node_values");
		for(int i = 0; i < node_values.length; i++){
			for(int j = 0; j < node_values[i].length; j++){
				System.out.println("   node_value["+i+"]["+j+"] = "+ node_values[i][j]);
			}
		}
		System.out.println("node_indexes");
		for(int i = 0; i < node_indexes.length; i++){
			for(int j = 0; j < node_indexes[i].length; j++){
				System.out.println("   node_indexes["+i+"]["+j+"] = "+node_indexes[i][j]);
			}
		}
		System.out.println("node_class_labels");
		for(int i = 0; i < node_class_labels.length; i++){
			System.out.println("   node_class_labels["+i+"] = "+node_class_labels[i]);
		}
	}

	public static void konvertujPodatke(String imefajla1, String imefajla2, String imefajla3){
		ArrayList<String[]> lista = new ArrayList<>();
		ArrayList<String> lista2 = new ArrayList<>();
	    try {
		  File fajl1 = new File(imefajla1);
		  Scanner myReader = new Scanner(fajl1);
		  while (myReader.hasNextLine()) {
		    String[] niz = myReader.nextLine().split(",");
            lista.add(niz);
		  }
		  myReader.close();
		} catch (FileNotFoundException e) {
		  System.out.println("Greska.");
		  e.printStackTrace();
	   }
	    try {
		  File fajl2 = new File(imefajla2);
		  Scanner myReader1 = new Scanner(fajl2);
		  while (myReader1.hasNextLine()) {
		    String niz = myReader1.nextLine();
            lista2.add(niz);
		  }
		  myReader1.close();
		} catch (FileNotFoundException e) {
		  System.out.println("Greska.");
		  e.printStackTrace();
	   }

	   String[] rez = new String[lista.size()];

	   for(int i = 0; i<rez.length; i++){
		   String[] st = lista.get(i);
		   String s = lista2.get(i);
		   for(int j = 0; j<st.length; j++){
			   s = s + " " +(j+1)+":" + st[j];
		   }
		   rez[i] = s;
		   System.out.println(s);
	   }
	   PrintWriter printWriter = null;
	   try{
		    FileWriter fileWriter = new FileWriter(imefajla3);
			printWriter = new PrintWriter(fileWriter);
			for(int i = 0; i < rez.length; i++){
				printWriter.print(rez[i]+"\n");
			}
	   }catch (IOException e) {
		  System.out.println("Greska.");
		  e.printStackTrace();
	   }finally{
		   printWriter.close();
	   }
	}
}