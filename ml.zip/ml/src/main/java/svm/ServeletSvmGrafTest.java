package svm;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import svm.libsvm.*;
import com.google.gson.Gson;

/**
 * Servlet implementation class ServeletSvmGrafTest
 */
public class ServeletSvmGrafTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletSvmGrafTest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    // Logika za generisanje matrica
	    SVM svm = (SVM) request.getSession().getAttribute("svm");
		svm_model model = (svm_model) request.getSession().getAttribute("model");

	    double[][] X1 = (double[][]) request.getSession().getAttribute("X1");
	    double[][] matrica2 = {{5.0, 6.0}, {7.0, 8.0}};
	////////////////////////////////////////    
			double[][] x = svm.dataset1.node_values();
			double[] y = svm.dataset1.node_class_labels();

			ArrayList<double[]> lista1 = new ArrayList<>();
	        ArrayList<double[]> lista2 = new ArrayList<>();
	        double xMin = x[0][0];
	        double xMax = x[0][0];
	        double yMin = x[0][1];
	        double yMax = x[0][1];
	        for(int i = 0; i<x.length; i++){
				if(y[i] == 1){
					lista1.add(x[i]);
				} else{
					lista2.add(x[i]);
				}
				//naci min i max za x i y osu
				if(xMin>x[i][0])
				   xMin = x[i][0];
				if(xMax<x[i][0])
				   xMax = x[i][0];

				if(yMin>x[i][1])
				   yMin = x[i][1];
				if(yMax<x[i][1])
				   yMax = x[i][1];
			}
	        Integer sirina =  500;
	        Integer visina  =  400;

			double xKorak = (xMax-xMin)/sirina;
			double yKorak = (yMax-yMin)/visina;	
       
			ArrayList<double[]> lista01 = new ArrayList<>();
	        ArrayList<double[]> lista02 = new ArrayList<>();
	        xMin = xMin - (xMax-xMin)/7;
	        xMax = xMax + (xMax-xMin)/7;
	        yMin = yMin - (yMax-yMin)/7;
	        yMax = yMax + (yMax-yMin)/7;
			for(double i = xMin; i < xMax; i+=xKorak){
				for(double j = yMin; j < yMax; j+=yKorak){
					int[] indeksi={1,2};
					double[] vrednosti = {i, j};
	                double klasa = svm.klasa(indeksi, vrednosti, model);
	                if(klasa == 1.0){
						lista01.add(vrednosti);
					} else {
						lista02.add(vrednosti);
					}
				}
			}
			double[][] niz011 = lista01.toArray(new double[lista01.size()][2]);
			double[][] niz021 = lista02.toArray(new double[lista02.size()][2]);
			double[][] niz01 = new double[niz011.length][niz011[0].length];
			for(int i = 0; i<niz01.length; i++){
				for(int j = 0; j<niz01[0].length; j++){
					niz01[i][j] = niz011[i][j];
				}
			}
			double[][] niz02 = new double[niz021.length][niz021[0].length];
			for(int i = 0; i<niz02.length; i++){
				for(int j = 0; j<niz02[0].length; j++){
					niz02[i][j] = niz021[i][j];
				}
			}			
			double[][] niz1 = lista1.toArray(new double[lista1.size()][2]);
			double[][] niz2 = lista2.toArray(new double[lista2.size()][2]);
	////////////////////////////////////////////
	    // Pretvaranje matrica u JSON
	    Gson gson = new Gson();
	    String jsonMatrica1 = gson.toJson(niz1);
	    String jsonMatrica2 = gson.toJson(niz2);
	    String jsonMatrica3 = gson.toJson(niz01);
	    String jsonMatrica4 = gson.toJson(niz02);
	    // Kreiranje JSON objekta za slanje
	    
	    String jsonOdgovor = "{\"matrica1\":" + jsonMatrica1 + ", \"matrica2\":" + jsonMatrica2 + 
	    		", \"matrica3\":" + jsonMatrica3 + ", \"matrica4\":" + jsonMatrica4 +"}";
	    // Slanje odgovora
	    response.getWriter().write(jsonOdgovor);
	}
}
