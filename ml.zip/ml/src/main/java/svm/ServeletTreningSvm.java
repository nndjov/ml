package svm;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import NeuronskaMreza;
import svm.libsvm.*;
/**
 * Servlet implementation class ServeletTreningSvm
 */
//@WebServlet("/serveletTreningSvm")
public class ServeletTreningSvm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletTreningSvm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsonTrening = "[]";
		String jsonTest = "[]";
		String jsonMatrice ="[]";
		String jsonNiz = "[]";
		double[] nizGreske;
		  				
				double[][]ulazniPodaci = (double[][]) request.getSession().getAttribute("matricaUlaza");
				double[][]izlazniPodaci = (double[][]) request.getSession().getAttribute("matricaIzlaza");		
			    boolean normalizacijaDaNe = (boolean) request.getSession().getAttribute("normalizacijaDaNe");
			    double procenatTest = (double) request.getSession().getAttribute("procenatTest");

				
				int granica = 0;
				LinkedList<String> listaPodataka = new LinkedList<String>();
				
				if(ulazniPodaci!=null && izlazniPodaci!=null){			
					granica = (int)(((double)ulazniPodaci.length)*procenatTest/100.00);
					granica = ulazniPodaci.length-granica;
					for(int i = 0; i < ulazniPodaci.length; i++){
						String s = "";
						String s1 = "";
						for(int j = 0; j < ulazniPodaci[0].length; j++){	
							int rb = j+1;
							s1 = s1 + rb+":"+ulazniPodaci[i][j]+" ";
						}
						s = ((int)izlazniPodaci[i][0])+" "+s1;
						listaPodataka.add(s);
					}
		        }
				
				SVM svm = new SVM();
				svm.ucitajPodatke(listaPodataka, granica);
		// parametri
			    StringBuilder sb = new StringBuilder();
			    BufferedReader reader = request.getReader();
			    String linija;
			    while ((linija = reader.readLine()) != null) {
			        sb.append(linija);
			    }
			    JSONParser parser = new JSONParser();
			    JSONObject jsonObjekat = null;
			    try {
			        jsonObjekat = (JSONObject) parser.parse(sb.toString());
			    } catch (ParseException e) {
			        e.printStackTrace();
			    }
			    
			    //PARAMETRI
			    int svm_type = Integer.valueOf((String) jsonObjekat.get("svm_type"));
			    int kernel_type = Integer.valueOf((String) jsonObjekat.get("kernel_type"));
			    int degree = Integer.valueOf((String) jsonObjekat.get("degree"));
			    double gamma = Double.valueOf((String)jsonObjekat.get("gamma"));
			    double coef0 = Double.valueOf((String)jsonObjekat.get("coef0"));
			    double cachesize = Double.valueOf((String)jsonObjekat.get("cachesize"));
			    double epsilon = Double.valueOf((String)jsonObjekat.get("epsilon"));
			    double cost = Double.valueOf((String)jsonObjekat.get("cost"));
			    double nu = Double.valueOf((String)jsonObjekat.get("nu"));
			    int probability = Integer.valueOf((String) jsonObjekat.get("probability"));
			    
		    	//double alfa = Double.valueOf((String)jsonObjekat.get("learningRate"));
		    	//int greska = Integer.valueOf((String) jsonObjekat.get("errorType"));

		    	svm_problem prob = svm.model(svm.dataset);
		    	svm_parameter param = svm.setParametar(svm_type,kernel_type, degree, gamma, coef0,cachesize, epsilon, cost, nu, probability);
		        //svm_parameter param = svm.setParametar(0,0,0,0.802,0,20000,0.0001,100,0.5,1);
		        svm_model model = svm.trening(prob, param);
		        
		        
		        request.getSession().setAttribute("svm", svm);
		        request.getSession().setAttribute("prob", prob);
		        request.getSession().setAttribute("param", param);
		        request.getSession().setAttribute("model", model);   
				
				
		        String rezultat = "Model optimization\n";
		               rezultat+= "-------------------\n";
		        rezultat+= Rezultat.rez+"\n\n";       
		        rezultat+= svm.testSve(svm.dataset1,model)+"\n\n";
              
		        rezultat += svm.matricaKonfuzije()+"\n";
/*		        
				double[][] teta= model.sv_coef;
		        for(int i = 0; i < teta.length; i++){
					for(int j = 0; j < teta[0].length; j++){
						rezultat += "teta["+i+"]["+j+"] = "+teta[i][j]+"\n";
					}
				}       
*/	

				//scriptSafeRezOblik = rezOblik.replace("'", "\\'").replace("\n", "\\n");
		///////////////Vracanje rezultata
		    response.setContentType("text/plain; charset=UTF-8");
		    // Kreiranje PrintWriter objekta za slanje odgovora
		    PrintWriter out1 = response.getWriter();
		    // Slanje stringa nazad klijentu
		    out1.print(rezultat);
		    out1.close();
	}

}
