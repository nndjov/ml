
import java.util.*;

public class Sloj{
	private static int redBr = 1;
	private double[][] ulazi;
	private double[][] W; // tezine
	private double[][] B; // Bias
	private double[][] Z;
    private int brojNeurona; // broj neurona na sloju

    private int redniBrojSloja;
    private int brojUlaza;

	public enum AktivacionaFja {
		 TANH, SIGLOG, LINEAR;
	}

	AktivacionaFja aktivacionaFja;

    public Sloj(int brojNeurona, int brojUlaza){
		this.redniBrojSloja = redBr;
		redBr++;
		this.brojNeurona = brojNeurona;
		this.brojUlaza = brojUlaza;

		aktivacionaFja = AktivacionaFja.SIGLOG;

		W = Matrica.slucajnaMatrica(brojNeurona, brojUlaza);
        //B = Matrica.slucajnaMatrica(brojNeurona,1);
        B = Matrica.nulaMatrica(brojNeurona,1);
	}

	public void postaviAktivacionuFju(AktivacionaFja aktivacionaFja){
		this.aktivacionaFja = aktivacionaFja;
	}
	public AktivacionaFja vratiAktivacionuFju(){
		return aktivacionaFja;
	}

	public void postaviTezine(double[][] W){
		this.W = W;
	}

	public void postaviUlaze(double[][] ulazi){
		this.ulazi = ulazi;
		//B = Matrica.slucajnaMatrica(brojNeurona, ulazi[0].length);
		//B = Matrica.slucajnaMatrica(brojNeurona, 1);
	}

	public void postaviBiase(double[][] B){
		this.B = B;
	}

	public double[][] vratiTezine(){
		return W;
	}
	public double[][] vratiUlaze(){
		return ulazi;
	}
	public double[][] vratiBiase(){
		return B;
	}
	public double[][] vratiZ(){
		double[][] B1 = new double[B.length][ulazi[0].length];
		for(int i =0; i < B1.length; i++){
			for(int j =0; j < B1[0].length; j++){
				B1[i][j] = B[i][0];
			}
		}
        Z = Matrica.div(Matrica.add(Matrica.mul(W,(ulazi)), B1),  NeuronskaMreza.m);
		//Z = Matrica.add(Matrica.div(Matrica.mul(W,(ulazi)), NeuronskaMreza.m), B1);
		return Z;
	}

	public int brojNeurona(){
		return brojNeurona;
	}
    public double[][] izlaz(){

		double[][] B1 = new double[B.length][ulazi[0].length];
		for(int i =0; i < B1.length; i++){
			for(int j =0; j < B1[0].length; j++){
				B1[i][j] = B[i][0];
			}
		}
        Z = Matrica.div(Matrica.add(Matrica.mul(W,(ulazi)), B1), NeuronskaMreza.m);
        //Z = Matrica.add(Matrica.div(Matrica.mul(W,(ulazi)), NeuronskaMreza.m), B1);
        double[][] A = fja(Z);
        return A;
	}

//////////

private void normalizacija(double[] x) {

	double zbirKvadrata = 0.0;
	for(int i = 0; i < x.length; i++){
			zbirKvadrata = zbirKvadrata + x[i]*x[i];

	}
    for(int i = 0; i < x.length; i++){
			x[i] = x[i]*(1.0/Math.sqrt(zbirKvadrata) );
	}

/*
    double min = Double.MAX_VALUE;
    double max = Double.MIN_VALUE;
    double sum = 0;
    for (double pixel : x) {
        sum = sum + pixel;
        if (pixel > max) {
            max = pixel;
        }
        if (pixel < min) {
            min = pixel;
        }
    }
    double mean = sum / x.length;
    for (int i = 0; i < x.length; i++) {
        x[i] = (x[i] - mean)/(max - min);
    }
*/
}

private void normalizacija(double[][] x) {

	double zbirKvadrata = 0.0;
	for(int i = 0; i < x.length; i++){
		for(int j = 0; j<x[0].length; j++){
			zbirKvadrata = zbirKvadrata + x[i][j]*x[i][j];
		}

	}
    for(int i = 0; i < x.length; i++){
		for(int j = 0; j<x[0].length; j++){
			x[i][j] = x[i][j]*(1.0/Math.sqrt(zbirKvadrata) );
		}

	}

/*
    double min = Double.MAX_VALUE;
    double max = Double.MIN_VALUE;
    double sum = 0;
    for (int i = 0; i < x.length; i++) {
		for(int j = 0; j<x[0].length; j++){
			sum = sum + x[i][j];
			if (x[i][j] > max) {
				max = x[i][j];
			}
			if (x[i][j] < min) {
				min = x[i][j];
			}
		}
    }
    double sred = sum / x.length;
    for (int i = 0; i < x.length; i++) {
		for(int j = 0; j<x[0].length; j++){
			x[i][j] = (x[i][j] - sred)/(max - min);
		}

    }
*/

}

///////
	double fja(double x){
		double a = 0;
        if (aktivacionaFja == AktivacionaFja.SIGLOG){
			a = 1/(1+Math.exp(-x));
		} else if (aktivacionaFja == AktivacionaFja.TANH){
			//a = (1-Math.exp(-x))/(1+Math.exp(-x));
			//a = (Math.exp(x)-Math.exp(-x))/(Math.exp(x)+Math.exp(-x));
            a = Math.tanh(x);

		} else if (aktivacionaFja == AktivacionaFja.LINEAR){
			a = x;
		}
        return a;
	}

    public double[][] fja(double[][] a) {
        int m = a.length;
        int n = a[0].length;
        double[][] z = new double[m][n];
        if (aktivacionaFja == AktivacionaFja.SIGLOG){
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					z[i][j] = (1.0 / (1.0 + Math.exp(-a[i][j])));
				}
			}
		}else if (aktivacionaFja == AktivacionaFja.TANH){
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					//z[i][j] = ((1 - Math.exp(-a[i][j]))/(1 + Math.exp(-a[i][j])));
					//z[i][j] = ((Math.exp(a[i][j])- Math.exp(-a[i][j]))/(Math.exp(a[i][j]) + Math.exp(-a[i][j])));
					z[i][j]= Math.tanh(a[i][j]);

				}
			}
		}else if (aktivacionaFja == AktivacionaFja.LINEAR){
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
                    z[i][j] = a[i][j];
				}
			}
		}
        return z;
    }

    public double[][] izvod(double[][] a) {
        int m = a.length;
        int n = a[0].length;
        double[][] z = new double[m][n];
        if (aktivacionaFja == AktivacionaFja.SIGLOG){
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					z[i][j] = (1.0 -(1.0 / (1.0 + Math.exp(-a[i][j])))) * (1.0 / (1.0 + Math.exp(-a[i][j])));
				}
			}
		}else if (aktivacionaFja == AktivacionaFja.TANH){
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					z[i][j]= 1.0 - Math.tanh(a[i][j])*Math.tanh(a[i][j]);
				}
			}
		}else if (aktivacionaFja == AktivacionaFja.LINEAR){
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					z[i][j] = 1;
				}
			}
		}
        return z;
	}
}