//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.*;

import nn.*;
/**
 * Servlet implementation class ServeletDataSetPrepoznavanje
 */
public class ServeletDataSetPrepoznavanje extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletDataSetPrepoznavanje() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	    JSONParser parser = new JSONParser();
	    BufferedReader reader = request.getReader();
	    JSONObject json = null;
	    try {
	    	json = (JSONObject) parser.parse(reader);
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }	    

	    JSONArray jsonMatricaPrepoznavanje = (JSONArray) json.get("podaci");

	    String[][] matricaPrepoznavanja = jsonArrayToMatrix(jsonMatricaPrepoznavanje);
	    request.getSession().setAttribute("matricaPrepoznavanja", matricaPrepoznavanja);
	    request.getSession().setAttribute("matricaUlaza", null);
	    request.getSession().setAttribute("matricaIzlaza", null);
	    request.getSession().setAttribute("normalizacijaDaNe", false);
	    request.getSession().setAttribute("procenatTest", 0.0);
	     	    

	}
    private String[][] jsonArrayToMatrix(JSONArray jsonArray) {
	String[][] matrix = new String[jsonArray.size()][];
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONArray jsonRow = (JSONArray) jsonArray.get(i);
            String[] row = new String[jsonRow.size()];
            for (int j = 0; j < jsonRow.size(); j++) {
                row[j] = (jsonRow.get(j).toString());
            }
            matrix[i] = row;
        }
        return matrix;
    }	

}
