//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import nn.*;

/**
 * Servlet implementation class ServeletNNGrafTest
 */
public class ServeletNNGrafTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletNNGrafTest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsonTest = "[]";
		NeuronskaMreza nn = (NeuronskaMreza) request.getSession().getAttribute("nn");	
		
	    double[][] X1 = (double[][]) request.getSession().getAttribute("X1");
	    double[][] Y1 = (double[][]) request.getSession().getAttribute("Y1");  

	    double[][] podaci11 = new double[X1.length][2];
		
		for(int i = 0; i < X1.length; i++){
			double[][] ul1 = new double[1][X1[0].length];
			for(int j = 0; j < X1[0].length; j++){
				ul1[0][j] = X1[i][j];
			}
			double[][] iz1 = nn.realanIzlaz((ul1));

			podaci11[i][0] = Y1[i][0];
			podaci11[i][1] = iz1[0][0];				
		}

		// Konverzija u JSON
		StringBuilder sb = new StringBuilder("[");
		for (int i = 0; i < podaci11.length; i++) {
		    sb.append("[");
		    for (int j = 0; j < podaci11[i].length; j++) {
		        sb.append(podaci11[i][j]);
		        if (j < podaci11[i].length - 1) sb.append(",");
		    }
		    sb.append("]");
		    if (i < podaci11.length - 1) sb.append(",");
		}
		sb.append("]");
		jsonTest = sb.toString();
		response.getWriter().write(jsonTest);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
