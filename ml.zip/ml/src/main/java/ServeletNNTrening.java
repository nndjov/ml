//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import nn.*;

/**
 * Servlet implementation class ServeletNNTrening
 */
public class ServeletNNTrening extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletNNTrening() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		double X[][];
		double Y[][];
		double X1[][];
		double Y1[][];	
		X1 = null;
		Y1 = null;
		double[][]ulazniPodaci = (double[][]) request.getSession().getAttribute("matricaUlaza");
		double[][]izlazniPodaci = (double[][]) request.getSession().getAttribute("matricaIzlaza");		
	    Boolean normalizacijaDaNe = (boolean) request.getSession().getAttribute("normalizacijaDaNe");
	    Double procenatTest = (double) request.getSession().getAttribute("procenatTest");
			
		String[][] matricaPrepoznavanja = (String[][]) request.getSession().getAttribute("matricaPrepoznavanja");
		String matricaOblika[][];
    	
		if(matricaPrepoznavanja!=null){
			X = new double[matricaPrepoznavanja.length][matricaPrepoznavanja[0].length-1];
			Y = new double[matricaPrepoznavanja.length][matricaPrepoznavanja.length];
			matricaOblika = new String[matricaPrepoznavanja.length][1];
			for(int i =0; i < matricaPrepoznavanja.length; i++){
				for(int j = 0; j<matricaPrepoznavanja[0].length-1; j++ ){
					if(i==j){
						Y[i][j]=1.0;
					}
					X[i][j]= Double.valueOf(matricaPrepoznavanja[i][j]);
				}
				matricaOblika[i][0] = matricaPrepoznavanja[i][matricaPrepoznavanja[0].length-1];
			}	
			request.getSession().setAttribute("matricaOblika", matricaOblika);
			
		} else if(ulazniPodaci!=null && izlazniPodaci!=null){			
			int index = (int)(((double)ulazniPodaci.length)*procenatTest/100.00);
			index = ulazniPodaci.length-index;
			X = new double[index][ulazniPodaci[0].length];
			X1 = new double[ulazniPodaci.length-index][ulazniPodaci[0].length];
     
			if(normalizacijaDaNe){
				Matrica.normalizacija(ulazniPodaci);
				System.out.println("Izvrsena normalizacija ");	
			}
            for(int i = 0; i < ulazniPodaci.length; i++){
            	for(int j = 0;j<ulazniPodaci[0].length; j++){
	            	if (i<index){
	            		X[i][j]=ulazniPodaci[i][j];            		
	            	}else{
	            		X1[i-index][j]=ulazniPodaci[i][j]; 
	            	}
            	}            	
            }
			Y = new double[index][izlazniPodaci[0].length];
			Y1 = new double[ulazniPodaci.length-index][izlazniPodaci[0].length];

            for(int i = 0; i < izlazniPodaci.length; i++){
            	for(int j = 0;j<izlazniPodaci[0].length; j++){
	            	if (i<index){
	            		Y[i][j]=izlazniPodaci[i][j];            		
	            	}else{
	            		Y1[i-index][j]=izlazniPodaci[i][j]; 
	            	}
            	}            	
            }             		
        }else{
    		double X11[][] = {
    				{0,0},
    				{0,1},
    				{1,0},
    				{1,1}
    			 };
    		double[][] Y11 =  {
    				{0},
    				{1},
    				{1},
    				{1}
    		};        
    		X = X11;
    		Y = Y11;
    		
    		double X111[][] = {
    				{0,0},
    				{0,1},
    				{1,0},
    				{1,1}
    			 };
    		double[][] Y111 =  {
    				{0},
    				{1},
    				{1},
    				{1}
    		};        
    		X1 = X111;
    		Y1 = Y111;    		
        }
		
		request.getSession().setAttribute("X", X);
		request.getSession().setAttribute("X1", X1);
		request.getSession().setAttribute("Y", Y);
		request.getSession().setAttribute("Y1", Y1);

///////       

////////// Obrada AJAX zahteva
    StringBuilder sb = new StringBuilder();
    BufferedReader reader = request.getReader();
    String linija;
    while ((linija = reader.readLine()) != null) {
        sb.append(linija);
    }
    JSONParser parser = new JSONParser();
    JSONObject jsonObjekat = null;
    try {
        jsonObjekat = (JSONObject) parser.parse(sb.toString());
    } catch (ParseException e) {
        e.printStackTrace();
    }


    double alfa = Double.valueOf((String)jsonObjekat.get("learningRate"));
    int greska = Integer.valueOf((String) jsonObjekat.get("errorType"));
    int brojEpoha = Integer.valueOf((String) jsonObjekat.get("numberEpoch"));
    JSONArray niz = (JSONArray) jsonObjekat.get("konfiguracija");
	/////////
	int[] konfiguracija = new int[niz.size()];
	
	for (int i = 0; i < niz.size(); i++) {
	    // Pretpostavljam da su podaci u JSONArray-u Long ili Integer, pa ih prvo konvertujemo u Long
	    Long temp = (Long) niz.get(i);
	    konfiguracija[i] = temp.intValue(); // Konverzija Long u int
	}

///////////      
		NeuronskaMreza nn = new NeuronskaMreza(X, Y, konfiguracija);		
		nn.setAlfa(alfa);
		nn.setError(greska);
		nn.setEpoch(brojEpoha);	

////////		
		String af = ""; //aktivaciona funkcija
		for(int i = 1; i < nn.getBrojSlojeva();i++){	
			af = (String) jsonObjekat.get("transferFunction"+i);
			if(af != null){
			if(af.equals("siglog")){
				nn.getSloj(i).postaviAktivacionuFju(Sloj.AktivacionaFja.SIGLOG);
			} else if(af.equals("tanh")){
				nn.getSloj(i).postaviAktivacionuFju(Sloj.AktivacionaFja.TANH);
			}else if(af.equals("linear")){
				nn.getSloj(i).postaviAktivacionuFju(Sloj.AktivacionaFja.LINEAR);
			}	
			}
		}				
		nn.trening();  
		request.getSession().setAttribute("nn", nn);
		//getServletContext().setAttribute("globalnaNN", nn);		
		String afRez="";
		for(int i = 1; i < nn.getBrojSlojeva();i++){
			Sloj sloj = nn.getSloj(i);
			String aff="";
			if(sloj!=null){
				aff = sloj.vratiAktivacionuFju().name();
			}				
			afRez = afRez +"\nActivation Function-Layer" + i + ":\n"+aff;
		}		
		String rezultat = " TRAINING RESULT\n" +
						  "--------------------\n\n"+
						  "ERROR: "+nn.vratiTipGreske()+"\n"+
		                  "Learning Rate: " + alfa +"\n"+
		                  "NUMBER OF EPOCH: " + brojEpoha +"\n" +
		                  afRez+ "\n\n"+
		                  "Current error: " + nn.vratiTekucuGresku()
		                  ;
 
		//scriptSafeRezOblik = rezOblik.replace("'", "\\'").replace("\n", "\\n");
///////////////Vracanje rezultata
    response.setContentType("text/plain; charset=UTF-8");
    // Kreiranje PrintWriter objekta za slanje odgovora
    PrintWriter out1 = response.getWriter();
    // Slanje stringa nazad klijentu
    out1.print(rezultat);
    out1.close();
	}

}
