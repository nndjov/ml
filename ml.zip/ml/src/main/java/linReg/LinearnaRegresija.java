package linReg;

import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.util.*;

public class LinearnaRegresija {
    private double[] koeficijenti;

    private double learningRate;
    private int brojIteracija;
    private double lambda; // parametar regularizacije
    private double tolerance; // Prag konvergencije
    private boolean normalizacijaDaNe;
    private int tipRegularizacije;
    // 0 - bez
    // 1 - L1
    // 2 - L2

    private List<Double> mseHistory;
    //cuvaju se podaci za normalizaciju
    private double[] minValues;
    private double[] maxValues;

    public LinearnaRegresija(double learningRate, int brojIteracija, double lambda, double tolerance) {
		this();
        this.learningRate = learningRate;
        this.brojIteracija = brojIteracija;
        this.lambda = lambda;
        this.tolerance = tolerance;
        this.mseHistory = new ArrayList<>();
    }
    public LinearnaRegresija() {
		normalizacijaDaNe = false;
		tipRegularizacije = 0;
        this.mseHistory = new ArrayList<>();
    }
    public void setLearningRate(double learningRate) {
        this.learningRate = learningRate;
    }
    public void setBrojIteracija(int brojIteracija) {
        this.brojIteracija = brojIteracija;
    }
    public void setLambda(double lambda) {
        this.lambda = lambda;
    }
    public void setTolerance(double tolerance) {
        this.tolerance = tolerance;
    }
    public void setNormalizacijaDaNe(boolean normalizacijaDaNe){
		this.normalizacijaDaNe = normalizacijaDaNe;
	}
    
    public void setTipRegularizacije(int tipRegularizacije) {
    	this.tipRegularizacije = tipRegularizacije;
    }

    public void trening(double[][] X, double[] y) {
		int numFeatures = X[0].length;
		this.koeficijenti = new double[numFeatures + 1]; // +1 for the intercept
        if (X.length != y.length) {
            throw new IllegalArgumentException("Broj redova matrice X i vektor y moraju biti iste duzine!");
        }
        double[][] normalizedX = null;

        if(normalizacijaDaNe){
			normalizedX = normalize(X);
		}else{
			normalizedX = X;
		}

        int n = normalizedX.length;
        numFeatures = koeficijenti.length - 1;

        for (int i = 0; i < brojIteracija; i++) {
            double[] gradients = new double[koeficijenti.length];
            double mse = 0;

            for (int j = 0; j < n; j++) {
                double predicted = predict(normalizedX[j]);
                double error = predicted - y[j];
                mse += error * error / n;
                gradients[0] += error / n; // Gradient for intercept
                for (int k = 1; k <= numFeatures; k++) {
					if(tipRegularizacije == 1){
						//L1 regularizacija
                    	gradients[k] += (error * normalizedX[j][k - 1] / n) + (lambda * Math.signum(koeficijenti[k])/n);
					} else if(tipRegularizacije == 2){
						// L2 regularizacija
                    	gradients[k] += (error * normalizedX[j][k - 1] / n) + (lambda * koeficijenti[k]/n);
					} else {
						// Bez regularizacije
						gradients[k] += error * X[j][k - 1] / n;
					}
                }
            }

            mseHistory.add(mse);

            // Check for convergence
            if (i > 0 && Math.abs(mseHistory.get(i) - mseHistory.get(i - 1)) < tolerance) {
                System.out.println("Converged after " + i + " brojIteracija.");
                break;
            }
            for (int j = 0; j < gradients.length; j++) {
                koeficijenti[j] = koeficijenti[j] - learningRate * gradients[j];
            }
        }
    }

    private double[][] normalize(double[][] X) {
        double[][] normalizedX = new double[X.length][X[0].length];
        minValues = new double[X[0].length];
        maxValues = new double[X[0].length];

        for (int i = 0; i < X[0].length; i++) {
            minValues[i] = Double.MAX_VALUE;
            maxValues[i] = Double.MIN_VALUE;
        }
        for (double[] row : X) {
            for (int i = 0; i < row.length; i++) {
                if (row[i] < minValues[i]) minValues[i] = row[i];
                if (row[i] > maxValues[i]) maxValues[i] = row[i];
            }
        }
        for (int i = 0; i < X.length; i++) {
            for (int j = 0; j < X[0].length; j++) {
                normalizedX[i][j] = (X[i][j] - minValues[j]) / (maxValues[j] - minValues[j]);
            }
        }
        return normalizedX;
    }
    // Dodajte novu metodu za normalizaciju novih podataka koristeći sačuvane parametre skaliranja
    public double[] normalizeNewData(double[] x) {
		if(minValues != null && maxValues!=null){
			double[] normalizedX = new double[x.length];
			for (int i = 0; i < x.length; i++) {
				normalizedX[i] = (x[i] - minValues[i]) / (maxValues[i] - minValues[i]);
			}
			return normalizedX;
		}else{
			return null;
		}
    }

    public double predict(double[] x) {
        double result = koeficijenti[0]; // intercept
        for (int i = 1; i < koeficijenti.length; i++) {
            result += koeficijenti[i] * x[i - 1];
        }
        return result;
    }

    public double[] getCoefficients() {
        return koeficijenti;
    }

    public List<Double> getMseHistory() {
        return mseHistory;
    }
    public double[] vratiGresku(){
		double[] arr = mseHistory.stream().mapToDouble(Double::doubleValue).toArray();
		return arr;
	}
//
	public double[][] ucitajPodatke(String imefajla){
		ArrayList<String[]> lista = new ArrayList<>();
	    try {
		  File myObj = new File(imefajla);
		  Scanner myReader = new Scanner(myObj);
		  while (myReader.hasNextLine()) {
		    String[] niz = myReader.nextLine().split(",");
            lista.add(niz);
		  }
		  myReader.close();
		} catch (FileNotFoundException e) {
		  System.out.println("An error occurred.");
		  e.printStackTrace();
	   }

	   double[][] rez = new double[lista.size()][lista.get(0).length];

	   for(int i = 0; i<rez.length; i++){
		   String[] st = lista.get(i);
		   for(int j = 0; j<rez[0].length; j++){
			   rez[i][j] = Double.parseDouble(st[j]);
		   }
	   }
	   return rez;
	}
//
}

