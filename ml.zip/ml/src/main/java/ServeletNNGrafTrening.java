//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import nn.*;

/**
 * Servlet implementation class ServeletNNGrafTrening
 */
public class ServeletNNGrafTrening extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletNNGrafTrening() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsonTrening = "[]";
		NeuronskaMreza nn = (NeuronskaMreza) request.getSession().getAttribute("nn");		
		//NeuronskaMreza nn = (NeuronskaMreza) getServletContext().getAttribute("globalnaNN");
	    double[][] X = (double[][]) request.getSession().getAttribute("X");
	    double[][] Y = (double[][]) request.getSession().getAttribute("Y");
	    
	    //double[][] X = (double[][]) getServletContext().getAttribute("matricaUlaza");
	    //double[][] Y = (double[][]) getServletContext().getAttribute("matricaIzlaza");   
	    
	    double[][] podaci1 = new double[X.length][2];	
		for(int i = 0; i < X.length; i++){
			double[][] ul = new double[1][X[0].length];
			for(int j = 0; j < X[0].length; j++){
				ul[0][j] = X[i][j];
			}
			double[][] iz = nn.realanIzlaz((ul));

			podaci1[i][0] = Y[i][0];
			podaci1[i][1] = iz[0][0];
			
		}		
	// Konverzija u JSON
		StringBuilder sb1 = new StringBuilder("[");
		for (int i = 0; i < podaci1.length; i++) {
		    sb1.append("[");
		    for (int j = 0; j < podaci1[i].length; j++) {
		        sb1.append(podaci1[i][j]);
		        if (j < podaci1[i].length - 1) sb1.append(",");
		    }
		    sb1.append("]");
		    if (i < podaci1.length - 1) sb1.append(",");
		}
		sb1.append("]");
		jsonTrening = sb1.toString();
		response.getWriter().write(jsonTrening);	
	}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
