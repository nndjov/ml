package logReg;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ServeletGrafLogReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ServeletGrafLogReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsonTrening = "[]";
		double[][] X = (double[][]) request.getSession().getAttribute("matricaUlaza");
		double[][] Y = (double[][]) request.getSession().getAttribute("matricaIzlaza");   
	    
	    double[][] podaci = new double[X.length][X[0].length+Y[0].length];
	    System.out.println("X.length "+X.length);
	    System.out.println("Y.length "+Y.length);
		for(int i = 0; i < X.length; i++){
			for(int j = 0; j<X[0].length; j++){
				podaci[i][j] = X[i][j];			
			}
			podaci[i][X[0].length] = Y[i][0];
			
		}		
	// Konverzija u JSON
		StringBuilder sb1 = new StringBuilder("[");
		for (int i = 0; i < podaci.length; i++) {
		    sb1.append("[");
		    for (int j = 0; j < podaci[i].length; j++) {
		        sb1.append(podaci[i][j]);
		        if (j < podaci[i].length - 1) sb1.append(",");
		    }
		    sb1.append("]");
		    if (i < podaci.length - 1) sb1.append(",");
		}
		sb1.append("]");
		jsonTrening = sb1.toString();
		response.getWriter().write(jsonTrening);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
