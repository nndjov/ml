package logReg;

import java.util.*;
import java.io.*;

public class LogistickaRegresija {

    private double alfa;
    private int brojEpoha;
    private int tipRegularizacije;
    private double lambda;
    private boolean normalizacijDaNe;

	private double[] teta;
	double[] errors;

	double[][] x;
	double[] y;

    private double[] minValues; // Minimalne vrednosti u svakoj koloni
	private double[] maxValues; // Maksimalne vrednosti u svakoj koloni

	int TP = 0;
	int TN = 0;
	int FP = 0;
	int FN = 0;

	public LogistickaRegresija(double alfa, int brojEpoha, double lambda){
		this.alfa = alfa;
		this.brojEpoha = brojEpoha;
		this.lambda = lambda;
		tipRegularizacije = 0;
	}

	public void trening(double[][] x, double[] y) {
	    this.x = x;
	    this.y = y;
	    teta = new double[x[0].length + 1];
	
	    if (normalizacijDaNe) {
	        x = normalize(x);
	    }
	
	    errors = new double[brojEpoha];
	    for (int iter = 0; iter < brojEpoha; iter++) {
	        double[] gradijenti = izracunajGradient(x, y, teta);
	        for (int j = 0; j < teta.length; j++) {
	            teta[j] -= alfa * gradijenti[j];
	        }
	
	        // Izračunaj grešku u ovoj iteraciji i spremi je u niz grešaka
	        double[] predvidjanja = predvidi(x);
	        double totalCost = 0;
	        for (int i = 0; i < y.length; i++) {
	            totalCost += y[i] * Math.log(predvidjanja[i]) + (1 - y[i]) * Math.log(1 - predvidjanja[i]);
	        }
	        errors[iter] = -totalCost / y.length;
	    }
	}


    // Funkcija za izračunavanje parcijalnih derivacija
    public double[] izracunajGradient(double[][] x, double[] y, double[] teta) {
        int n = y.length;
        double[] gradijenti = new double[teta.length];
        for (int i = 0; i < n; i++) {
            double pred = teta[0];
            double[] xi = x[i];
            for (int j = 1; j < teta.length; j++) {
                pred += teta[j] * xi[j-1];
            }
            pred = sigmoid(pred);
            double error = pred - y[i];
            gradijenti[0] +=  error;
            for (int j = 1; j < teta.length; j++) {
                gradijenti[j] += xi[j-1] * error;
            }
        }

        if (tipRegularizacije == 2) {         //L2 regularizacija
            for (int j = 1; j < teta.length; j++) {
                gradijenti[j] /= n;
                gradijenti[j] += 2 * lambda * teta[j];
            }
        } else if (tipRegularizacije == 1) {
            for (int j = 1; j < teta.length; j++) {
                gradijenti[j] /= n;
                gradijenti[j] += lambda * Math.signum(teta[j]);
            }
        } else{
            for (int j = 1; j < teta.length; j++) {
                gradijenti[j] /= n;
            }
		}
        return gradijenti;
    }

    // Funkcija za izracun predvidenih vrednosti na temelju koeficijenata
    public double[] predvidi(double[][] x) {
        int n = x.length;
        double[] predvidjanja = new double[n];

        for (int i = 0; i < n; i++) {
			double[] xi = x[i];
            double prediction = teta[0];
            for (int j = 1; j < teta.length; j++) {
                prediction += teta[j] * xi[j-1];
            }
            prediction = sigmoid(prediction);
            //predvidjanja[i] = (Math.abs(prediction) >= 0.5) ? 1 : 0;
            //predvidjanja[i] = ((prediction) >= 0.5) ? 1 : 0;
            predvidjanja[i] = prediction;
        }
        return predvidjanja;
    }

    public double[] predvidiKlasu(double[][] x) {
        int n = x.length;
        double[] predvidjanja = new double[n];

        for (int i = 0; i < n; i++) {
			double[] xi = x[i];
            double prediction = teta[0];
            for (int j = 1; j < teta.length; j++) {
                prediction += teta[j] * xi[j-1];
            }
            prediction = sigmoid(prediction);
            predvidjanja[i] = (Math.abs(prediction) >= 0.5) ? 1 : 0;
            //predvidjanja[i] = ((prediction) >= 0.5) ? 1 : 0;
            //predvidjanja[i] = prediction;
        }
        return predvidjanja;
    }

    // Metoda za računanje matrice konfuzije
/*
    public int[][] matricaKonfuzije(double[] actual, double[] predicted) {
        int[][] matrica = new int[2][2];
        for (int i = 0; i < actual.length; i++) {
            int stvarnaKLsa =  (int)actual[i];
            int predvidjenaKLasa = (int)predicted[i];
            matrica[stvarnaKLsa][predvidjenaKLasa]++;
        }
        return matrica;
    }
*/
    public int[][] matricaKonfuzije(){
		int[][] mc = new int[2][2];
		mc[0][0] = TP;
		mc[0][1] = FP;
		mc[1][0] = FN;
		mc[1][1] = TN;
		return mc;
	}
    public double[] teta(){
		return teta;
	}
    public double[][] ucitajPodatke(String imefajla) {
        ArrayList<String[]> lista = new ArrayList<>();

        try {
            File myObj = new File(imefajla);
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String[] niz = myReader.nextLine().split("\\s+");
                lista.add(niz);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        double[][] rez = new double[lista.size()][lista.get(0).length];

        for (int i = 0; i < rez.length; i++) {
            String[] st = lista.get(i);

            for (int j = 0; j < rez[0].length; j++) {
                rez[i][j] = Double.parseDouble(st[j]);
            }
        }
        return rez;
    }

    public void setTipRegularizacije(int tipRegularizacije){
		this.tipRegularizacije = tipRegularizacije;
	}

    public double[] vratiGresku(){
		return errors;
	}

    // Sigmoid funkcija
    public static double sigmoid(double z) {
        return 1 / (1 + Math.exp(-z));
    }
// normalizacija
    public double[][] normalize(double[][] X) {
        double[][] normalizovanoX = new double[X.length][X[0].length];
        minValues = new double[X[0].length];
        maxValues = new double[X[0].length];

        for (int i = 0; i < X[0].length; i++) {
            minValues[i] = Double.MAX_VALUE;
            maxValues[i] = Double.MIN_VALUE;
        }
        for (double[] row : X) {
            for (int i = 0; i < row.length; i++) {
                if (row[i] < minValues[i]) minValues[i] = row[i];
                if (row[i] > maxValues[i]) maxValues[i] = row[i];
            }
        }
        for (int i = 0; i < X.length; i++) {
            for (int j = 0; j < X[0].length; j++) {
                normalizovanoX[i][j] = (X[i][j] - minValues[j]) / (maxValues[j] - minValues[j]);
            }
        }
        return normalizovanoX;
    }
    // metodu za normalizaciju novih podataka koristeći sačuvane parametre skaliranja
    public double[] normalizujNovePodatke(double[] x) {
		if(minValues != null && maxValues!=null){
			double[] normalizovanoX = new double[x.length];
			for (int i = 0; i < x.length; i++) {
				normalizovanoX[i] = (x[i] - minValues[i]) / (maxValues[i] - minValues[i]);
			}
			return normalizovanoX;
		}else{
			return null;
		}
    }

    public String toString(){
		String rez = "RESULT\n";
		      rez+= "----------------\n";
		      rez+= "Coefficients:\n";
		double teta[] = teta();
		for(int i = 0; i<teta.length; i++){
			rez += "  teta_"+i+" = " + teta[i] + "\n";
		}
		double[] predvidjanja = predvidi(x);
		int[][] mc = matricaKonfuzije();
		rez+= "\nConfusion Matrix:\n";
		for(int i = 0; i<mc.length; i++){
			rez += "  "+Arrays.toString(mc[i]) + "\n";
		}

		return rez;
	}

	public String test(double[][] xTest,  double[] yTest){
		String rez="";
		rez+="---------------------------------------------\n";
		rez+="-- Stvarna vrednost      Predvidjeno      ---\n";
		rez+="---------------------------------------------\n";
		TP = 0;
		TN = 0;
		FP = 0;
		FN = 0;
	    for(int i = 0; i < xTest.length; i++){
			double[][] pp = {xTest[i]};
			double[] predvidjanje  = predvidi(pp);

            //True Positive:(correctly detected)You predicted positive and it�s actual value is true(1).
			double pred = predvidjanje[0]>0.5 ? 1.0:0.0 ;
			if(pred == 1.0 && yTest[i]== 1.0){
				TP++;
			}
			//True Negative:(correctly rejected)You predicted negative and it�s actual value is true(1).
			if(pred == 0.0 && yTest[i]== 0.0){
				TN++;;
			}
            //False Positive: (Type 1 Error)(incorrectly detected)You predicted positive(1)
            //and it�s actual value is 0.Since, both values does not match ,its false.
			if(pred == 1.0 && yTest[i]== 0.0){
				FP++;
			}
			//False Negative: (Type 2 Error)(incorrectly rejected)You predicted negative(0)
			//and it�s actual value is 1.Since,both values does not match, again its false.
			if(pred == 0.0 && yTest[i]== 1.0){
				FN++;;
			}
			rez+="         "+ yTest[i] + "         -       " + pred + "     "+ (yTest[i]==pred ? "T" : "N")+"\n";
		}
		rez+= "  ["+TP +"   "+ FP+"]\n";
		rez+= "  ["+FN +"   "+ TN+"]\n";
	    return rez;
	}
/*
    public double greska() {
        // cross-entropy
        // greska2 = -1/m * suma(Y*logA +(1-Y)log(1-A))

        int m = x.length;
        double[] z = 0;
        for (int i = 0; i < m; i++) {
                z[i] = (y[i] * Math.log(Math.abs(A[i][j]))) + ((1 - y[i][j]) * Math.log(Math.abs(1 - A[i][j])));
        }
        double suma = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                suma += z[i][j];
            }
        }
        double rez = -suma/mm;
        return rez;
    }
*/
	public void setNormalizacijaDaNe(boolean normalizacijaDaNe) {
		this.normalizacijDaNe = normalizacijaDaNe;
	}
	public double precision(){
		return ((double)TP/((double)TP+(double)FP));
	}
	public double recall(){
		return ((double)TP/((double)TP+(double)FN));
	}
	public double accurancy(){
		return (((double)TP+(double)TN)/((double)TP+(double)TN + (double)FP + (double)FN));
	}	
}

