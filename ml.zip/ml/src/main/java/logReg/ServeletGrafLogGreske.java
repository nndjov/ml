package logReg;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.IOException;
import com.google.gson.Gson;


public class ServeletGrafLogGreske extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            	
    	LogistickaRegresija lr = (LogistickaRegresija) request.getSession().getAttribute("log");
        double[] nizGreske = lr.vratiGresku();

        Gson gson = new Gson();
        String jsonNiz = gson.toJson(nizGreske);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonNiz);
    }
}