//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

import com.google.gson.Gson;

import nn.*;

/**
 * Servlet implementation class ServeletNNTezine
 */
public class ServeletNNTezine extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletNNTezine() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsonMatrice = "[]";	
		//NeuronskaMreza nn = (NeuronskaMreza) getServletContext().getAttribute("globalnaNN");
		NeuronskaMreza nn = (NeuronskaMreza) request.getSession().getAttribute("nn");
	    List<double[][]> listaTezina = new ArrayList<>();
		for(int i = 1; i <= nn.getBrojSlojeva();i++){
			Sloj sloj = nn.getSloj(i);
			double[][] w =  Matrica.T(sloj.vratiTezine());					
			listaTezina.add(w);
		}	    
	    Gson gson = new Gson();
	    jsonMatrice = gson.toJson(listaTezina);
		response.getWriter().write(jsonMatrice);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
