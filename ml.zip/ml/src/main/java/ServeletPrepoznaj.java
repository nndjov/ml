//package nn;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.*;

import nn.*;
/**
 * Servlet implementation class ServeletPrepoznaj
 */
public class ServeletPrepoznaj extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletPrepoznaj() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String rezOblik="";
		String scriptSafeRezOblik = "";
		if(request.getMethod().equalsIgnoreCase("POST")) {
		    StringBuilder sb = new StringBuilder();
		    String s;
		    while ((s = request.getReader().readLine()) != null) {
		        sb.append(s);
		    }

		    Gson gson = new Gson();
		    // Preuzimanje objekta koji sadrži niz
		    JsonObject jsonObj = gson.fromJson(sb.toString(), JsonObject.class);

		    // Ekstrakcija niza iz objekta
		    double[] javaNiz = gson.fromJson(jsonObj.get("nizUlaza"), double[].class);

		    // Obrada Java niza
		    double[][] matricaUlaza = new double[1][javaNiz.length];
		    matricaUlaza[0] = javaNiz;
		    

		    NeuronskaMreza nn = (NeuronskaMreza) request.getSession().getAttribute("nn");
		    double[][] iz = nn.realanIzlaz((matricaUlaza));
		    for(int i = 0;i<iz.length; i++){
			  for(int j=0;j<iz[0].length;j++){
				  if(iz[i][j]>0.5){
					  iz[i][j]=1.0;
				  }else{
					  iz[i][j]=0.0;
				  }
			  }
		    }
		////////////
		    	rezOblik = "\nREZULTAT PREPOZNAVANJA\n";
		        String[][] oblici = (String[][]) request.getSession().getAttribute("matricaOblika");
		        String rezPrepoznavanja = "Nije prepoznat oblik!";
		        for(int i = 0; i < iz.length; i++){
		        	if(iz[i][0]==1.0){
			        	rezPrepoznavanja = oblici[i][0];      			
		        	}
		        }
		        rezOblik += rezPrepoznavanja+"\n\n";
				System.out.println(rezOblik);  
				scriptSafeRezOblik = rezOblik.replace("'", "\\'").replace("\n", "\\n");
		///////////////
		    response.setContentType("text/plain; charset=UTF-8");
		    // Kreiranje PrintWriter objekta za slanje odgovora
		    PrintWriter out1 = response.getWriter();
		    // Slanje stringa nazad klijentu
		    out1.print(rezPrepoznavanja);
		    out1.close();
		}
	}

}
