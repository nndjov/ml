
import java.util.*;
import javax.swing.*;

public class NeuronskaMreza{
	//Monitor mo =  new Monitor();
	private int BROJ_SLOJEVA ;
	private int brojNeurona[];
	private int brojUlaza[];

	private double[][] zeljeniUlazi;
	private double[][] zeljeniIzlazi;

	private double alfa;

	private ArrayList<Sloj> slojevi;
    private List<double[][]> W ;
    private List<double[][]> B ;

    public static int m;
    private int BROJ_ITERACIJA;

    private double nizGreske[];
    // greska1 = 1/m * suma(1/2(Y-A)(Y-A))
    // greska2 = -1/m * suma(Y*logA +(1-Y)log(1-A))
    public static final int GRESKA1 = 1;
    public static final int GRESKA2 = 2;
    private int tip_greske;
    private double tekucaGreska;

    public NeuronskaMreza(){
		alfa = 0.7;
		BROJ_ITERACIJA = 100000;
		tip_greske = GRESKA1;
	}

	public NeuronskaMreza(double[][] zeljeniUlazi, double[][] zeljeniIzlazi, int niz[]){
		this();
		this.zeljeniUlazi = zeljeniUlazi;
	    this.zeljeniIzlazi = Matrica.T(zeljeniIzlazi);

	    int numNeuron[] = new int[niz.length-1];
	    int inputNeuron[] = new int[niz.length-1];
	    for(int i = 0; i < inputNeuron.length; i++){
			inputNeuron[i] = niz[i];
		}
	    for(int i = 0; i < numNeuron.length; i++){
			numNeuron[i] = niz[i+1];
		}
	    this.brojNeurona = numNeuron;
	    this.brojUlaza = inputNeuron;
		m = zeljeniUlazi.length;
		BROJ_SLOJEVA = brojNeurona.length;
/*
		alfa = 0.9;
		BROJ_ITERACIJA = 100000;
		tip_greske = GRESKA1;
*/
		slojevi = new ArrayList<Sloj>(BROJ_SLOJEVA+1);
//    	W = new ArrayList<double[][]>(BROJ_SLOJEVA+1);
//    	B = new ArrayList<double[][]>(BROJ_SLOJEVA+1);

		for(int sloj = 0; sloj < BROJ_SLOJEVA+1; sloj++){
			slojevi.add(null);
		}

		for(int i = 0; i < BROJ_SLOJEVA; i++){
				Sloj sloj = new Sloj(brojNeurona[i], brojUlaza[i]);
				slojevi.set(i+1, sloj);
		}
//
		//slojevi.get(1).postaviAktivacionuFju(Sloj.AktivacionaFja.TANH);
		//slojevi.get(1).postaviAktivacionuFju(Sloj.AktivacionaFja.SIGLOG);
		//slojevi.get(2).postaviAktivacionuFju(Sloj.AktivacionaFja.LINEAR);

		slojevi.get(1).postaviUlaze(Matrica.T(zeljeniUlazi));
	}
    int epoha = 0;

	public void trening(){
    	W = new ArrayList<double[][]>(BROJ_SLOJEVA+1);
    	B = new ArrayList<double[][]>(BROJ_SLOJEVA+1);

		//Monitor.setMonitor("Training in progress!!!");
		//Monitor.setMonitor("--------------------------");
		//Monitor.setMonitor("  Learning rate = " + alfa);
		//Monitor.setMonitor("  Epoche = " + BROJ_ITERACIJA);
		if(tip_greske == GRESKA1){
			//Monitor.setMonitor("  ERROR TYPE: Mean squared error");
		} else if(tip_greske == GRESKA2){
			//Monitor.setMonitor("  ERROR TYPE: Cross-entropy cost function");
		}
		tekucaGreska = 0.0;
		nizGreske = new double[BROJ_ITERACIJA];
		boolean proveraGreske = false;

        for (int i = 0; i < BROJ_ITERACIJA; i++) {
            // forward propagation

            for(int sloj = 1; sloj < BROJ_SLOJEVA ; sloj++){
				slojevi.get(sloj+1).postaviUlaze(slojevi.get(sloj).izlaz());
			}

			if(tip_greske == GRESKA1){
				tekucaGreska = Matrica.greska1(m, zeljeniIzlazi, slojevi.get(BROJ_SLOJEVA).izlaz());
			} else if(tip_greske == GRESKA2){
				//tekucaGreska = Matrica.greska2(slojevi.get(BROJ_SLOJEVA).brojNeurona(), m, zeljeniIzlazi, slojevi.get(BROJ_SLOJEVA).izlaz());
				tekucaGreska = Matrica.greska2( m, zeljeniIzlazi, slojevi.get(BROJ_SLOJEVA).izlaz());
			}


			if(tekucaGreska < 0.1 && !proveraGreske){
				//Monitor.setMonitor("  The error is less than 0.01 after " + i + " epochs!");
				proveraGreske = true;
				//break;
			}

            nizGreske[i] = tekucaGreska;

////////////
            //backpropagation

            List<double[][]> dA = new ArrayList<double[][]>(BROJ_SLOJEVA+1);
            List<double[][]> dZ = new ArrayList<double[][]>(BROJ_SLOJEVA+1);
            List<double[][]> dW = new ArrayList<double[][]>(BROJ_SLOJEVA+1);
            List<double[][]> dB = new ArrayList<double[][]>(BROJ_SLOJEVA+1);
            for(int sloj = 0; sloj < BROJ_SLOJEVA+1; sloj++){
				dA.add(null);
				dZ.add(null);
				dW.add(null);
				dB.add(null);
			}

			double[][] dApom = null;;
			if(tip_greske == GRESKA1){
				//  ERROR TYPE: Mean squared error
				dApom =  Matrica.sub(slojevi.get(BROJ_SLOJEVA).izlaz(), zeljeniIzlazi);
			} else if(tip_greske == GRESKA2){
				//ERROR TYPE: Cross-entropy cost function
				dApom = Matrica.sub(Matrica.div(Matrica.sub(1.0, zeljeniIzlazi), Matrica.sub(1.0, slojevi.get(BROJ_SLOJEVA).izlaz())), Matrica.div(zeljeniIzlazi, slojevi.get(BROJ_SLOJEVA).izlaz()));
			}
			double[][] dZpom = Matrica.mnozenjeElemenata(dApom, slojevi.get(BROJ_SLOJEVA).izvod(slojevi.get(BROJ_SLOJEVA).vratiZ()));
			double[][] dWpom = Matrica.div(Matrica.mul(dZpom, Matrica.T(slojevi.get(BROJ_SLOJEVA).vratiUlaze())), m); ///
			//double[][] dBpom = Matrica.div(dZpom, m);
///////
			double[][] dZpom1 = Matrica.sumByRows(dZpom);
			double[][] dBpom = Matrica.div(dZpom1, m) ;
////// dBpom

			dA.set(BROJ_SLOJEVA, dApom);
			dZ.set(BROJ_SLOJEVA, dZpom);
			dW.set(BROJ_SLOJEVA, dWpom);
			dB.set(BROJ_SLOJEVA, dBpom);

			for(int sloj = BROJ_SLOJEVA-1; sloj > 0; sloj--){
				double [][] dA2 = Matrica.mul(Matrica.T(slojevi.get(sloj+1).vratiTezine()), dZ.get(sloj+1));
				double[][] dZ2 = Matrica.mnozenjeElemenata(dA2, slojevi.get(sloj).izvod(slojevi.get(sloj).vratiZ()));
				double[][]dW2;
				if (sloj == 1){
					dW2 = Matrica.div(Matrica.mul(dZ2,(zeljeniUlazi)), m);
				}else{
					//dW2 = Matrica.div(Matrica.mul(dZ2,Matrica.T(slojevi.get(sloj).vratiUlaze())), m);
					dW2 = Matrica.div(Matrica.mul(dZ2,Matrica.T(slojevi.get(sloj-1).izlaz())), m);
				}

				double[][] dZ2pom = Matrica.sumByRows(dZ2);
				double[][]dB2 = Matrica.div(dZ2pom, m) ;

				dA.set(sloj, dA2);
				dZ.set(sloj, dZ2);
				dW.set(sloj, dW2);
				dB.set(sloj, dB2);
			}
            for(int sloj = 0; sloj < BROJ_SLOJEVA+1; sloj++){
				W.add(null);
				B.add(null);
			}

			for(int sloj = 1; sloj < BROJ_SLOJEVA+1; sloj++){
				double[][] W1 = Matrica.sub(slojevi.get(sloj).vratiTezine(), Matrica.mnozenjeElemenata(alfa, dW.get(sloj)));
				double[][] B1 = Matrica.sub(slojevi.get(sloj).vratiBiase(), Matrica.mnozenjeElemenata(alfa, dB.get(sloj)));
	            W.set(sloj,W1);
	            B.set(sloj,B1);
			}
            for(int sloj = 1; sloj < BROJ_SLOJEVA+1; sloj++){
            	slojevi.get(sloj).postaviTezine(W.get(sloj));
            	slojevi.get(sloj).postaviBiase(B.get(sloj));
			}
            epoha++;

        }
/// Korekcija tezina
        for(int sloj = 1; sloj < BROJ_SLOJEVA+1; sloj++){
            slojevi.get(sloj).postaviTezine(Matrica.mnozenjeElemenata(1.0/m, W.get(sloj)));
            slojevi.get(sloj).postaviBiase(Matrica.mnozenjeElemenata(1.0/m, B.get(sloj)));
		}

        for(int sloj = 1; sloj < BROJ_SLOJEVA+1; sloj++){
			//Monitor.setMonitor("  Layer " + sloj + " - transfer function: " + slojevi.get(sloj).vratiAktivacionuFju());
		}

		System.out.println("  ERROR = " + tekucaGreska);

        //Monitor.setMonitor("  ERROR = " + tekucaGreska );
        //Monitor.setMonitor("  Epoche = " + epoha);
        //Monitor.setMonitor("Training completed!!!");
        epoha = 1;
	}

	public ArrayList<Sloj> getSlojevi(){
		return slojevi;
	}

    public double[][] realanIzlaz(double[][] ulaz){
        double[][] A3 = null;
		for(int sloj = 1; sloj < BROJ_SLOJEVA+1; sloj++){
			double[][] A2 = null;
			if(sloj==1){
				A2 = Matrica.mul(W.get(sloj), Matrica.T(ulaz));

				A2 = Matrica.add(A2, B.get(sloj));
				A2 = Matrica.mnozenjeElemenata((1.0/m), A2);
				A2 = slojevi.get(sloj).fja(A2);
				A3 = A2;
			}else{
				A2 = Matrica.mul(W.get(sloj), A3);
				A2 = Matrica.add(A2, B.get(sloj));
				A2 = Matrica.mnozenjeElemenata((1.0/m), A2);
				A2 = slojevi.get(sloj).fja(A2);
				A3=A2;
			}
			//A3 = Matrica.div(A2, m);
		}
		return A3;
	}

    public String stringIzlaz(double[][] ulaz){
		double[][] A3= null;

		for(int sloj = 1; sloj < BROJ_SLOJEVA+1; sloj++){
			double[][] A2 = null;
			if(sloj==1){
				A2 = Matrica.mul(W.get(sloj), Matrica.T(ulaz));
				A2 = Matrica.add(A2, B.get(sloj));
				A2 = slojevi.get(sloj).fja(A2);
				A3 = A2;
			}else{
				A2 = Matrica.mul(W.get(sloj), A3);
				A2 = Matrica.add(A2, B.get(sloj));
				A2 = slojevi.get(sloj).fja(A2);
				A3=A2;
			}
			A3 = A2;
		}
		 double max = 0;
		 int index = 0;
		 for(int i = 0; i < A3.length; i++){
			 if(A3[i][0] > max){
				 max = A3[i][0];
				 index = i;
			 }
		 }
		 int[] izlaz = new int[A3.length];
		 izlaz[index] = 1;
		 String binarno="";

		 for(int i = 0; i < izlaz.length; i++){
			  binarno = binarno + izlaz[i] + "  ";
		 }
		return binarno;

	}
    public void setError(int error){
			this.tip_greske = error;
	}
    public void setEpoch(int e){
			this.BROJ_ITERACIJA = e;
	}

	public int getEpoch(){
		return BROJ_ITERACIJA ;
	}

	public void setAlfa(double alfa){
		this.alfa = alfa;
	}
	public double getAlfa(){
		return alfa;
	}

    public Sloj  getSloj(int i){
		return slojevi.get(i);
	}

	public int getBrojSlojeva(){
		return BROJ_SLOJEVA;
	}

	public double[] vartiNizGreske(){
		return nizGreske;
	}

	public void setZeljeniUlazi(double[][] zljeniUlazi){
		this.zeljeniUlazi = zeljeniUlazi;
	}
	public double[][] getZeljeniUlazi(){
		return zeljeniUlazi;
	}

	public String vratiTipGreske(){
		String tipGreske="";
		if(tip_greske == GRESKA1){
			tipGreske = "Mean squared error";
		} else if(tip_greske == GRESKA2){
			tipGreske = "Cross-entropy cost function";
		}
		return tipGreske;
	}
	public double vratiTekucuGresku() {
		return tekucaGreska;
	}
}