package polReg;


import Jama.Matrix;
import Jama.QRDecomposition;
import java.util.*;
import java.io.*;

public class PolinomijalnaRegresija1  {
    private String ime;
    private int stepen;
    private Matrix teta;
    private double sse;
    private double sst;
    double[] x;
    double[] y;

    public PolinomijalnaRegresija1(double[] x, double[] y, int stepen) {
        this(x, y, stepen, "n");
    }

    public PolinomijalnaRegresija1(double[] x, double[] y, int stepen, String ime) {
    	this.x = x;
    	this.y = y;
        this.stepen = stepen;
        this.ime = ime;
        int n = x.length;
        QRDecomposition qr = null;
        Matrix matricaX = null;

        while (true) {
            double[][] vm = new double[n][this.stepen+1];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j <= this.stepen; j++) {
                    vm[i][j] = Math.pow(x[i], j);
                }
            }
            matricaX = new Matrix(vm);

            qr = new QRDecomposition(matricaX);
            if (qr.isFullRank()) break;
            this.stepen--;
        }

        Matrix matricaY = new Matrix(y, n);
        teta = qr.solve(matricaY);
        double sum = 0.0;
        for (int i = 0; i < n; i++)
            sum += y[i];
        double mean = sum / n;
        for (int i = 0; i < n; i++) {
            double dev = y[i] - mean;
            sst += dev*dev;
        }

        Matrix residuals = matricaX.times(teta).minus(matricaY);
        sse = residuals.norm2() * residuals.norm2();
    }

    public double teta(int j) {
        if (Math.abs(teta.get(j, 0)) < 1E-4) return 0.0;
        return teta.get(j, 0);
    }
    
    public double[] getCoefficients() {
    	double[][] mat = teta.getArray();
    	double[] niz = new double[mat.length];
    	for(int i = 0; i<mat.length; i++) {
    		niz[i]=mat[i][0];   		
    	}
    	return niz;
    }

    public Matrix teta(){
		return teta;
	}
    
    public double getSST() {
    	return sst;
    }
    public double getSSE() {
    	return sse;
    }
    public int stepen() {
        return stepen;
    }

    public double R2() {
        if (sst == 0.0) return 1.0;
        return 1.0 - sse/sst;
    }

    public double proceni(double x) {
        double y = 0.0;
        for (int j = stepen; j >= 0; j--)
            y = teta(j) + (x * y);
        return y;
    }
    
    public String toString() {
        StringBuilder s = new StringBuilder();
        double[] koef = getCoefficients();
        int j = stepen;
        //while (j >= 0 && Math.abs(teta(j)) < 1E-5)
        //    j--;

        while (j >= 0) {
            if      (j == 0) s.append(String.format("%.3f ", koef[j]));
            else if (j == 1) s.append(String.format("%.3f %s + ", koef[j], ime));
            else             s.append(String.format("%.3f %s^%d + ", koef[j], ime, j));
            j--;
        }
        s = s.append("\n  (R^2 = " + String.format("%.3f", R2()) + ")");
        return s.toString().replace("+ -", "- ");
        
    }
    public double vratiGresku() {
    	double greska = 0.0;
    	for(int i=0;i<x.length; i++) {
    		double procena = proceni(x[i]);
    		greska+= Math.abs((procena - y[i]));
    	}
        return greska/((double)x.length);
    }
    
	public static double[][] ucitajPodatke(String imefajla){
		ArrayList<String[]> lista = new ArrayList<>();
	    try {
		  File myObj = new File(imefajla);
		  Scanner myReader = new Scanner(myObj);
		  while (myReader.hasNextLine()) {
		    String[] niz = myReader.nextLine().split(",");
            lista.add(niz);
		  }
		  myReader.close();
		} catch (FileNotFoundException e) {
		  System.out.println("GRESKA.");
		  e.printStackTrace();
	   }

	   double[][] rez = new double[lista.size()][lista.get(0).length];

	   for(int i = 0; i<rez.length; i++){
		   String[] st = lista.get(i);
		   for(int j = 0; j<rez[0].length; j++){
			   rez[i][j] = Double.parseDouble(st[j]);
		   }
	   }
	   return rez;
	}
}