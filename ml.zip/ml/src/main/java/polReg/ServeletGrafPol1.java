package polReg;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonPrimitive;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ServeletGrafPol1 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Simulacija podataka (prilagodite vašim stvarnim podacima)
		double[][] ulazi = (double[][]) request.getSession().getAttribute("matricaUlaza");
		double[][] izlazi = (double[][]) request.getSession().getAttribute("matricaIzlaza"); 
        
		PolinomijalnaRegresija1 pr = (PolinomijalnaRegresija1) request.getSession().getAttribute("pr1");
		double[] koeficijenti = pr.getCoefficients();
		
		JsonArray jsoncoef = new JsonArray();
		for (double koef : koeficijenti) {
			jsoncoef.add(new JsonPrimitive(koef));
		}		

        // Kreiranje JSON objekta za odgovor
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.addProperty("status", "success");
        jsonResponse.add("matricaUlaza", convertArrayToJsonArray(ulazi));
        jsonResponse.add("matricaIzlaza", convertArrayToJsonArray(izlazi));
        jsonResponse.add("koeficijenti", jsoncoef);

        // Postavljanje odgovora
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(jsonResponse.toString());
    }

    // Pomoćna funkcija za konvertovanje liste u JSON niz
    protected JsonArray convertArrayToJsonArray(double[][] array) {
        JsonArray jsonArray = new JsonArray();
        for (double[] row : array) {
            JsonArray rowArray = new JsonArray();
            for (double value : row) {
                rowArray.add(value);
            }
            jsonArray.add(rowArray);
        }
        return jsonArray;
    }  
    
}