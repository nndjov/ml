package polReg;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import svm.libsvm.svm_model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.*;
import org.json.simple.parser.*;




/**
 * Servlet implementation class ServeletSvmUse
 */
public class ServeletPolRegUse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletPolRegUse() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PolinomijalnaRegresija pr = (PolinomijalnaRegresija) request.getSession().getAttribute("pr");

	////////////////////////////////////////    
			//double[][] x = (double[][])request.getSession().getAttribute("X1");
	//Prihvatanje matrice iz AJAXA
			   StringBuilder sb = new StringBuilder();
			    String s;
			    while ((s = request.getReader().readLine()) != null) {
			        sb.append(s);
			    }
			    JSONParser parser = new JSONParser();
			    JSONObject jsonObj=null;
				try {
					jsonObj = (JSONObject) parser.parse(sb.toString());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    JSONArray jsonMatrica = (JSONArray) jsonObj.get("matrica");

			    // Konvertujte JSONArray u matricu
			    double[][] matricaUse = new double[jsonMatrica.size()][];
			    for (int i = 0; i < jsonMatrica.size(); i++) {
			        JSONArray red = (JSONArray) jsonMatrica.get(i);
			        matricaUse[i] = new double[red.size()];
			        for (int j = 0; j < red.size(); j++) {
			        	matricaUse[i][j] = (double) red.get(j);
			        }
			    }	
         double[][] rez = new double[matricaUse.length][2];
	     for(int i = 0; i < matricaUse.length; i++) {
	    	 rez[i][0] = matricaUse[i][0];
	    	 rez[i][1] = pr.predict(matricaUse[i])[0];
	     }
	//////

	    // Kreiranje JSON objekta za slanje nazad
	    JSONObject odgovor = new JSONObject();
	    //odgovor.put("matrica3", niz01);
	    //odgovor.put("matrica4", niz02);
	    odgovor.put("rezUse", rez);
	   // odgovor.put("rezUse", rezUse);

	    // Slanje odgovora
	    response.getWriter().print(odgovor.toJSONString());
	    	    
//////////
	    
	}
}
