package polReg;

import java.util.*;
import java.io.*;

public class PolinomijalnaRegresija {

    private double alpha; // Learning rate
    private int iterations; // Maximum number of iterations
    private int polynomialDegree;
    private int regularizationType;
	private double[] coefficients; // Model parameters
	double[] errors;

    private double lambda; // Regularization coefficient
    private boolean normalizeInput; // Whether to normalize input data
    private double[] minValues; // Minimalne vrednosti u svakoj koloni
	private double[] maxValues; // Maksimalne vrednosti u svakoj koloni

	public PolinomijalnaRegresija(double alpha, int iterations, int polynomialDegree, double lambda){
		this.alpha = alpha;
		this.iterations = iterations;
		this.polynomialDegree = polynomialDegree;
		this.lambda = lambda;
		coefficients = new double[polynomialDegree+1];
		regularizationType = 0;
	}

    // Funkcija za izracun predvidenih vrednosti na temelju koeficijenata
    public double[] predict(double[] x) {
        int n = x.length;
        double[] predictions = new double[n];
        for (int i = 0; i < n; i++) {
            double prediction = 0;
            for (int j = 0; j < coefficients.length; j++) {
                prediction += coefficients[j] * Math.pow(x[i], j);
            }
            predictions[i] = prediction;
        }
        return predictions;
    }

    // Funkcija za ažuriranje koeficijenata koristeći gradijentni spust
    public void gradientDescent(double[] x, double[] y) {
		if(normalizeInput){
			//x = normalize(x);
		}
        int degree = polynomialDegree;
        errors = new double[iterations];
        for (int iter = 0; iter < iterations; iter++) {
            double[] gradients = computeGradient(x, y, coefficients);
            for (int j = 0; j <= degree; j++) {
                coefficients[j] -= alpha * gradients[j];
            }
 ////
            // Izračunaj grešku u ovoj iteraciji i spremi je u niz grešaka
            double[] predictions = predict(x);
            double sumSquaredErrors = 0;
            for (int i = 0; i < y.length; i++) {
                double error = predictions[i] - y[i];
                sumSquaredErrors += Math.pow(error, 2);
            }
            errors[iter] = sumSquaredErrors / (2 * y.length);
 ////
        }
    }

    // Funkcija za izračunavanje parcijalnih derivacija
    public double[] computeGradient(double[] x, double[] y, double[] coefficients) {
        int n = x.length;
        int degree = coefficients.length;
        double[] gradients = new double[degree];
        for (int i = 0; i < n; i++) {
            double prediction = 0;
            for (int j = 0; j < degree; j++) {
                prediction += coefficients[j] * Math.pow(x[i], j);
            }
            double error = prediction - y[i];
            for (int j = 0; j < degree; j++) {
                gradients[j] += Math.pow(x[i], j) * error;
            }
        }

        if (regularizationType == 2) {
            for (int j = 1; j < degree; j++) {
                gradients[j] /= n;
                gradients[j] += 2 * lambda * coefficients[j];
            }
        } else if (regularizationType == 1) {
            for (int j = 1; j < degree; j++) {
                gradients[j] /= n;
                gradients[j] += lambda * Math.signum(coefficients[j]);
            }
        }
        return gradients;
    }

    public double[] coefficients(){
		return coefficients;
	}
    public double[][] ucitajPodatke(String imefajla) {
        ArrayList<String[]> lista = new ArrayList<>();

        try {
            File myObj = new File(imefajla);
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                String[] niz = myReader.nextLine().split(",");
                lista.add(niz);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        double[][] rez = new double[lista.size()][lista.get(0).length];

        for (int i = 0; i < rez.length; i++) {
            String[] st = lista.get(i);

            for (int j = 0; j < rez[0].length; j++) {
                rez[i][j] = Double.parseDouble(st[j]);
            }
        }
        return rez;
    }

    public void setTipRegularizacije(int regularizationType){
		this.regularizationType = regularizationType;
	}

    public double[] vratiGresku(){
		return errors;
	}
// normalizacija
    private double[][] normalize(double[][] X) {
        double[][] normalizedX = new double[X.length][X[0].length];
        minValues = new double[X[0].length];
        maxValues = new double[X[0].length];

        for (int i = 0; i < X[0].length; i++) {
            minValues[i] = Double.MAX_VALUE;
            maxValues[i] = Double.MIN_VALUE;
        }
        for (double[] row : X) {
            for (int i = 0; i < row.length; i++) {
                if (row[i] < minValues[i]) minValues[i] = row[i];
                if (row[i] > maxValues[i]) maxValues[i] = row[i];
            }
        }
        for (int i = 0; i < X.length; i++) {
            for (int j = 0; j < X[0].length; j++) {
                normalizedX[i][j] = (X[i][j] - minValues[j]) / (maxValues[j] - minValues[j]);
            }
        }
        return normalizedX;
    }
    // metodu za normalizaciju novih podataka koristeći sačuvane parametre skaliranja
    public double[] normalizeNewData(double[] x) {
		if(minValues != null && maxValues!=null){
			double[] normalizedX = new double[x.length];
			for (int i = 0; i < x.length; i++) {
				normalizedX[i] = (x[i] - minValues[i]) / (maxValues[i] - minValues[i]);
			}
			return normalizedX;
		}else{
			return null;
		}
    }
    
    public String toString() {
        StringBuilder s = new StringBuilder();
        double[] koef = coefficients();
        int j = polynomialDegree;
        //while (j >= 0 && Math.abs(teta(j)) < 1E-5)
        //    j--;

        while (j >= 0) {
            if      (j == 0) s.append(String.format("%.3f ", koef[j]));
            else if (j == 1) s.append(String.format("%.3f %s + ", koef[j], "x"));
            else             s.append(String.format("%.3f %s^%d + ", koef[j], "x", j));
            j--;
        }
        //s = s.append("\n  (R^2 = " + String.format("%.3f", R2()) + ")");
        return s.toString().replace("+ -", "- ");
        
    }    
}
