package polReg;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import NeuronskaMreza;
import polReg.*;


/**
 * Servlet implementation class ServeletTreningLiReg
 */
public class ServeletTreningPolReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletTreningPolReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String jsonTrening = "[]";
		String jsonTest = "[]";
		String jsonMatrice ="[]";
		String jsonNiz = "[]";
		double[] nizGreske;
		  				
				double[][]ulazniPodaci = (double[][]) request.getSession().getAttribute("matricaUlaza");
				double[][]izlazniPodaci = (double[][]) request.getSession().getAttribute("matricaIzlaza");		
			    boolean normalizacijaDaNe = (boolean) request.getSession().getAttribute("normalizacijaDaNe");
			    double procenatTest = (double) request.getSession().getAttribute("procenatTest");

				
				int granica = 0;
				granica = (int)(((double)ulazniPodaci.length)*procenatTest/100.00);
				granica = ulazniPodaci.length-granica;				
			
				// parametri
			    StringBuilder sb = new StringBuilder();
			    BufferedReader reader = request.getReader();
			    String linija;
			    while ((linija = reader.readLine()) != null) {
			        sb.append(linija);
			    }
			    JSONParser parser = new JSONParser();
			    JSONObject jsonObjekat = null;
			    try {
			        jsonObjekat = (JSONObject) parser.parse(sb.toString());
			    } catch (ParseException e) {
			        e.printStackTrace();
			    }
			    
			    //PARAMETRI   			    
			    int numEpoch = Integer.valueOf((String) jsonObjekat.get("numEpoch"));			    
			    double learningRate = Double.valueOf((String)jsonObjekat.get("learningRate"));			    
			    double lambda = Double.valueOf((String)jsonObjekat.get("lambda"));			    			    
			    int reg_type = Integer.valueOf((String) jsonObjekat.get("reg_type"));
			    int stepen = Integer.valueOf((String) jsonObjekat.get("stepen"));
			    
			    //PolinomijalnaRegresija pr = new PolinomijalnaRegresija(learningRate, numEpoch,lambda, tolerance,3);
			    //PolinomijalnaRegresija pr = new PolinomijalnaRegresija(0.5, 1000, 0.01, 1e-6, 5);
			    
			    //pr.setNormalizacijaDaNe(normalizacijaDaNe);
			    //pr.setTipRegularizacije(reg_type);
			    
			    double[] xDat = new double[izlazniPodaci.length];
			    double[] yDat = new double[izlazniPodaci.length];
			    for(int i = 0; i < izlazniPodaci.length; i++) {
			    	xDat[i]= ulazniPodaci[i][0];
			    	yDat[i]= izlazniPodaci[i][0];
			    }
			    PolinomijalnaRegresija pr = new PolinomijalnaRegresija(learningRate, numEpoch, stepen, lambda);			    
			    pr.gradientDescent(xDat, yDat);
			    request.getSession().setAttribute("pr", pr);
				
		        String rezultat = "Result\n";
		               rezultat+= "-------------------\n";
		               rezultat+= "---Coefficients----\n";
		        double[] koeficijenti = pr.coefficients();
		        System.out.println("Koeficijenti:");
		        for (int i = 0; i < koeficijenti.length; i++) {
		        	rezultat+= "b" + i + ": " + koeficijenti[i]+"\n";
		        }
		        
		        rezultat+= "\ny = "+pr+"\n\n";
		        //rezultat+= "Error: " + pr.vratiGresku()+"\n";

////////////Vracanje rezultata
		    response.setContentType("text/plain; charset=UTF-8");
		    // Kreiranje PrintWriter objekta za slanje odgovora
		    PrintWriter out1 = response.getWriter();
		    // Slanje stringa nazad klijentu
		    out1.print(rezultat);
		    out1.close();
	}
}
