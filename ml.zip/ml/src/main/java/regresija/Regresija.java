package regresija;

import java.io.*;
import java.util.*;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class Regresija{
	private int EPOHA;
	double alfa;
	//private int BROJ_PARAMETARA = 2;
	int TP =0;
	int TN = 0;
	int FP = 0;
	int FN = 0;
	double[][] podaci;
	double[][] testPodaci;
	double x[][];
	double xTest[][];
	double y[][];
	double yTest[][];
	double teta[][];

	int[][] matricaKonfuzije;
	double[] greska;

	public Regresija(){
		matricaKonfuzije = new int[2][2];
	}

	public void setAlfa(double alfa){
		this.alfa = alfa;
	}
	public void setEpoha(int EPOHA){
		this.EPOHA = EPOHA;
		greska = new double[EPOHA];
	}
	
	public double[] vratiGresku() {
		return greska;
	}
	
	public void setPodaci(double[][] podaci) {
		this.podaci = podaci;
	}
	public void setTestPodaci(double[][] testPodaci) {
		this.testPodaci = testPodaci;
	}	
	public void urediPodatke(){
		x = new double[podaci.length][podaci[0].length];
		//x = new double[podaci.length][BROJ_PARAMETARA+1];
		xTest = new double[testPodaci.length][podaci[0].length];
		//xTest = new double[testPodaci.length][BROJ_PARAMETARA+1];
		teta = new double[podaci[0].length][1];
		//teta = new double[BROJ_PARAMETARA+1][1];
		y = new double[podaci.length][1];
		yTest = new double[testPodaci.length][1];
		for(int i = 0; i<podaci.length; i++){
			x[i][0] = 1;
			x[i][1] = podaci[i][0];
			x[i][2] = podaci[i][1];
			y[i][0] = podaci[i][2];
		}
		for(int i = 0; i<testPodaci.length; i++){
			xTest[i][0] = 1;
			xTest[i][1] = testPodaci[i][0];
			xTest[i][2] = testPodaci[i][1];
			yTest[i][0] = testPodaci[i][2];
		}
		for(int i = 0; i<teta.length; i++){
			teta[i][0] = 0;
		}
	}	
	
	public void trening(){
		//urediPodatke();
		int iteracija = 0;
		while(true){
            int m = x.length;
            //Gradient descent
			teta = Matrica.sub(teta, Matrica.mnozenjeElemenata((alfa/m),(gradient())));
			//GRESKA
			greska[iteracija] = greska();
			iteracija++;
			if(iteracija == EPOHA){
				break;
			}
		}
	}

	public void predvidjanje(double p[][]){
		double[][] predvidjanje = Matrica.sigmoid(Matrica.mul(p, teta));
		System.out.println("Za podatke " + p[0][1] + " , " +p[0][2] + " predvidjenje je " + predvidjanje[0][0]);
	}

	public String test( ){
		String rez="";
		rez+="---------------------------------------------\n";
		rez+="-- Stvarna vrednost      Predvidjeno      ---\n";
		rez+="---------------------------------------------\n";
		TP =0;
		TN = 0;
		FP = 0;
		FN = 0;
	    for(int i = 0; i < xTest.length; i++){
			double[][] pp = {xTest[i]};
			double[][] predvidjanje  = Matrica.sigmoid(Matrica.mul(pp, teta));
            //True Positive:(correctly detected)You predicted positive and it�s actual value is true(1).

			double pred = predvidjanje[0][0]>0.5 ? 1.0:0.0 ;
			if(pred == 1.0 && yTest[i][0]== 1.0){
				TP++;
			}
			//True Negative:(correctly rejected)You predicted negative and it�s actual value is true(1).
			if(pred == 0.0 && yTest[i][0]== 0.0){
				TN++;;
			}
            //False Positive: (Type 1 Error)(incorrectly detected)You predicted positive(1)
            //and it�s actual value is 0.Since, both values does not match ,its false.
			if(pred == 1.0 && yTest[i][0]== 0.0){
				FP++;
			}
			//False Negative: (Type 2 Error)(incorrectly rejected)You predicted negative(0)
			//and it�s actual value is 1.Since,both values does not match, again its false.
			if(pred == 0.0 && yTest[i][0]== 1.0){
				FN++;;
			}
			rez+="         "+ yTest[i][0] + "         -       " + pred + "     "+ (yTest[i][0]==pred ? "T" : "N")+"\n";
		}
	    return rez;
	}	


	public String matricaKonfuzije(){
		String rez="";		
		rez+="Matrica Konfuzije\n";
		rez+= TP + "  " + FP+"\n";
		rez+= FN + "  " + TN +"\n";
		return rez;
}
	public double precision(){
		return ((double)TP/((double)TP+(double)FP));
	}
	public double recall(){
		return ((double)TP/((double)TP+(double)FN));
	}
	public double accurancy(){
		return (((double)TP+(double)TN)/((double)TP+(double)TN + (double)FP + (double)FN));
	}
	public void ucitajPodatke(String imefajla){
		ArrayList<String[]> lista = new ArrayList<>();
	    try {
		  File myObj = new File(imefajla);
		  Scanner myReader = new Scanner(myObj);
		  while (myReader.hasNextLine()) {
		    String[] niz = myReader.nextLine().split(",");
            lista.add(niz);
		  }
		  myReader.close();
		} catch (FileNotFoundException e) {
		  System.out.println("Greska.");
		  e.printStackTrace();
	   }
	   //promesaj redove
//	   Collections.shuffle(lista);

	   double[][] rez = new double[lista.size()-lista.size()/5][lista.get(0).length];
	   for(int i = 0; i<rez.length; i++){
		   String[] st = lista.get(i);
		   for(int j = 0; j<rez[0].length; j++){
			   rez[i][j] = Double.parseDouble(st[j]);
		   }
	   }
	   podaci = rez;

	   double[][] rez1 = new double[lista.size() - rez.length][lista.get(0).length];
	   for(int i = 0; i<rez1.length; i++){
		   String[] st = lista.get(i+rez.length);
		   for(int j = 0; j<rez1[0].length; j++){
			   rez1[i][j] = Double.parseDouble(st[j]);
		   }
	   }
	   testPodaci = rez1;

		x = new double[podaci.length][podaci[0].length];
		//x = new double[podaci.length][BROJ_PARAMETARA+1];
		xTest = new double[testPodaci.length][podaci[0].length];
		//xTest = new double[testPodaci.length][BROJ_PARAMETARA+1];
		teta = new double[podaci[0].length][1];
		//teta = new double[BROJ_PARAMETARA+1][1];
		y = new double[podaci.length][1];
		yTest = new double[testPodaci.length][1];
		for(int i = 0; i<podaci.length; i++){
			x[i][0] = 1;
			x[i][1] = podaci[i][0];
			x[i][2] = podaci[i][1];
			y[i][0] = podaci[i][2];
		}
		for(int i = 0; i<testPodaci.length; i++){
			xTest[i][0] = 1;
			xTest[i][1] = testPodaci[i][0];
			xTest[i][2] = testPodaci[i][1];
			yTest[i][0] = testPodaci[i][2];
		}
		for(int i = 0; i<teta.length; i++){
			teta[i][0] = 0;
		}
	}

	public double[][] vratiPodatke(){
		return podaci;
	}
	public double[][] vratiTestPodatke(){
		return testPodaci;
	}

	public void normalizacija(){
		//for(int j =0; j < BROJ_PARAMETARA; j++){
		for(int j =0; j < podaci[0].length; j++){
			double max = 0.0;
			double min = 0.0;
			double suma = 0.0;

			for(int i = 0; i < podaci.length; i++){
				if(max < podaci[i][j])
				    max = podaci[i][j];
				if(min > podaci[i][j])
				    min = podaci[i][j];
				suma = suma + podaci[i][j];
			}
            double mi = suma/podaci.length; // Srednja vrednost

//////
            double sigma = 0.0; // Standardna devijacija
//            double mean = suma/podaci.length;
            double pom[] = new double[podaci.length];
            for(int i = 0; i < podaci.length; i++){
				pom[i]= podaci[i][j]-mi;
			}
            for(int i = 0; i < pom.length; i++){
				pom[i]= pom[i]*pom[i];
			}
			double s = 0.0;
            for(int i = 0; i < pom.length; i++){
				s = s+pom[i];
			}
			sigma = s/(podaci.length-1);
			sigma=Math.sqrt(sigma);
///////

			for(int i = 0; i < podaci.length; i++){
				podaci[i][j] = (podaci[i][j] - mi)/sigma;
			}
		}
        System.out.println("Normalizovani");
        Matrica.stampaj(podaci);
	}

	public void graf(){
		//Graf graf = new Graf("Primer", podaci);
		int k = 0;
		for(int i = 0; i < podaci.length; i++){
			if(podaci[i][2] == 0)
			   k++;
		}

		double[][] podaci0 = new double[k][2];
		double[][] podaci1 = new double[podaci.length - k][2];
		int br = 0;
		for(int i = 0; i < podaci.length; i++){
			if(podaci[i][2] == 0){
				podaci0[br][0] = podaci[i][0];
				podaci0[br][1] = podaci[i][1];
				br++;
			}
		}
		br = 0;
		for(int i = 0; i < podaci.length; i++){
			if(podaci[i][2] == 1){
				podaci1[br][0] = podaci[i][0];
				podaci1[br][1] = podaci[i][1];
				br++;
			}
		}
		//Graf graf = new Graf("Podaci", "Vred1", "Vred2");
		//graf.dodajPodatke("Nula", podaci0);
		//graf.dodajPodatke("Jedan", podaci1);
		//graf.prikazi();
    }

	public void grafRegresije(){
		int k = 0;
		for(int i = 0; i < podaci.length; i++){
			if(podaci[i][2] == 0)
			   k++;
		}
		double[][] podaci0 = new double[k][2];
		double[][] podaci1 = new double[podaci.length - k][2];
		double[][] podaci2 = new double[podaci.length][2];
		int br = 0;
		for(int i = 0; i < podaci.length; i++){
			if(podaci[i][2] == 0){
				podaci0[br][0] = podaci[i][0];
				podaci0[br][1] = podaci[i][1];
				br++;
			}
		}
		br = 0;
		for(int i = 0; i < podaci.length; i++){
			if(podaci[i][2] == 1){
				podaci1[br][0] = podaci[i][0];
				podaci1[br][1] = podaci[i][1];
				br++;
			}
		}
//// Graf regresije
	  double max = podaci[0][0];
	  double min = podaci[0][0];
	  for(int i =0; i < podaci.length; i++){
		  if (podaci[i][0] > max)
		       max = podaci[i][0];
		  if (podaci[i][0] < min)
		       min = podaci[i][0];
	  }
	  double korak = (max-min)/podaci.length;
	  double v = min;
	  for(int i =0; i < podaci.length; i++){
		  //Granica se racuna y(x) = -(t1/t2)*x - t0/t2
		  podaci2[i][0] = v;
		  podaci2[i][1] = -(teta[1][0]/teta[2][0])*v - teta[0][0]/teta[2][0];

		  //series3.add(v, -(teta[1][0]/teta[2][0])*v - teta[0][0]/teta[2][0]);
		  v = v+korak;
	  }
		//Graf graf = new Graf("Graf granice", "Vred1","Vred2");
		//graf.dodajPodatke("Nula", podaci0);
		//graf.dodajPodatke("Jedan", podaci1);
		//graf.dodajPodatke("Granica", podaci2);
		//graf.prikazi();
    }
/*
    public void grafGreske(){
		GrafGreske graf = new GrafGreske("Greska", "Epoch" , "Error", greska);
	}
*/
    public void grafGreske(){
		double[][] podaci0 = new double[greska.length][2];
		for(int i = 0; i < podaci0.length; i++){
				podaci0[i][0] = i;
				podaci0[i][1] = greska[i];
		}

		//Graf graf = new Graf("Greska","Epoha","Greska");
		//graf.dodajPodatke("Greska", podaci0);
		//graf.prikazi();
	}
	public double[][] gradient(){
		int m = y.length;
		double[][] h  = sigmoid(Matrica.mul(x,teta));
		double[][] pom = Matrica.mul(Matrica.T(x), Matrica.sub(h, y));
		return Matrica.mnozenjeElemenata((1.0/m), pom);
	}


    public double greska() {
        // cross-entropy
        // greska2 = -1/m * suma(Y*logA +(1-Y)log(1-A))

        double[][] pom = Matrica.mul(x,teta);
        double[][] A  = sigmoid(pom);
        int m = A.length;
        int n = A[0].length;
        int mm = x.length;
        double[][] z = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                //z[i][j] = (y[i][j] * Math.log((A[i][j]))) + ((1 - y[i][j]) * Math.log((1 - A[i][j])));
                z[i][j] = (y[i][j] * Math.log(Math.abs(A[i][j]))) + ((1 - y[i][j]) * Math.log(Math.abs(1 - A[i][j])));
            }
        }
        double suma = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                suma += z[i][j];
            }
        }
        double rez = -suma/mm;
        return rez;
    }

    //return sigmoid
    public double[][] sigmoid(double[][] a) {
        int m = a.length;
        int n = a[0].length;
        double[][] z = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                z[i][j] = (1.0 / (1 + Math.exp(-a[i][j])));
            }
        }
        return z;
    }

	public double sigmoid(double x){
		return 1/(1+Math.exp(-x));
	}

	public void setTeta(double[][] t){
		teta = t;
	}

    public void x(){
		System.out.println("X[]][] = ");
		Matrica.stampaj(x);
	}
    public void y(){
		System.out.println("y[]][] = ");
		Matrica.stampaj(y);
	}

    public String stampajTeta(){
    	String rez="";		
		for(int i = 0; i < teta.length;i++) {
			String rez1 = "";
			for(int j = 0; j < teta[0].length;j++) {
				rez1 += rez1 + "  " + teta[i][j];
			}
			rez = rez+rez1+"\n";
		}
		rez="TETA[]][] = \n"+rez;
		return rez;
	}
    
	public void stampajPodatke(){
	   System.out.println("Podaci");
	   Matrica.stampaj(podaci);
	}
}