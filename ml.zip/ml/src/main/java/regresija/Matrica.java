package regresija;

import java.util.*;
import java.util.Random;
import java.text.DecimalFormat;

public class Matrica {

    private static Random random = new Random();
    private static DecimalFormat df = new DecimalFormat("#.#####");

    //vraca vrednost u opsegu [0, 1).
    public static double slucajnaVrednost() {
        return random.nextDouble();
    }


    //vraca vrednost u opsegu [0, n).
    public static int slucajnaVrednost(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Argument mora biti pozitivan: " + n);
        }
        return random.nextInt(n);
    }

     //vraca vrednost u opsegu [a, b).
    public static int slucajnaVrednost(int a, int b) {
        if ((b <= a) || ((long) b - a >= Integer.MAX_VALUE)) {
            throw new IllegalArgumentException("Pogresan opseg: [" + a + ", " + b + ")");
        }
        return a + slucajnaVrednost(b - a);
    }

     //vraca vrednost u opsegu[a, b).
    public static double slucajnaVrednost(double a, double b) {
        if (!(a < b)) {
            throw new IllegalArgumentException("Pogresan opseg: [" + a + ", " + b + ")");
        }
        return a + slucajnaVrednost() * (b - a);
    }


    //vraca matricu sa slucajnim vrednostima
    public static double[][] slucajnaMatrica(int m, int n) {
        double[][] a = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = slucajnaVrednost(0.0, 1.0);
                //a[i][j] = 0.5;
            }
        }
        return a;
    }
    public static double[][] nulaMatrica(int m, int n) {
        double[][] a = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = 0.0;
            }
        }
        return a;
    }

     //Transponovana matrica
    public static double[][] T(double[][] a) {
        int m = a.length;
        int n = a[0].length;
        double[][] b = new double[n][m];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                b[j][i] = a[i][j];
            }
        }
        return b;
    }

     //return c = a + b
    public static double[][] add(double[][] a, double[][] b) {
        int m = a.length;
        int n = a[0].length;
        double[][] c = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = a[i][j] + b[i][j];
            }
        }
        return c;
    }

    public static double[][] add(double[][] a, double b) {
        int m = a.length;
        int n = a[0].length;
        double[][] c = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = a[i][j] + b;
            }
        }
        return c;
    }
     // return c = a - b
    public static double[][] sub(double[][] a, double[][] b) {
        int m = a.length;
        int n = a[0].length;
        double[][] c = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = a[i][j] - b[i][j];
            }
        }
        return c;
    }

    //return c = a - b
    public static double[][] sub(double a, double[][] b) {
        int m = b.length;
        int n = b[0].length;
        double[][] c = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = a - b[i][j];
            }
        }
        return c;
    }

    //return  a * b
    public static double[][] mul(double[][] a, double[][] b) {
        int m1 = a.length;
        int n1 = a[0].length;
        int m2 = b.length;
        int n2 = b[0].length;
        if (n1 != m2) {
            throw new RuntimeException("Illegal matrix dimensions.");
        }
        double[][] c = new double[m1][n2];
        for (int i = 0; i < m1; i++) {
            for (int j = 0; j < n2; j++) {
                for (int k = 0; k < n1; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return c;
    }

    // mnozenje elemenata matrice medjusobno x[i][j] * a[i][j]
    public static double[][] mnozenjeElemenata(double[][] b, double[][] a) {
        int m = a.length;
        int n = a[0].length;

        if (b.length != m || b[0].length != n) {
            throw new RuntimeException("Pogresna dimenzija matrice.");
        }
        double[][] c = new double[m][n];
        for (int j = 0; j < m; j++) {
            for (int i = 0; i < n; i++) {
                c[j][i] = a[j][i] * b[j][i];
            }
        }
        return c;
    }

    // mnozenje elemenat matrice skalarom
    public static double[][] mnozenjeElemenata(double x, double[][] a) {
        int m = a.length;
        int n = a[0].length;

        double[][] y = new double[m][n];
        for (int j = 0; j < m; j++) {
            for (int i = 0; i < n; i++) {
                y[j][i] = a[j][i] * x;
            }
        }
        return y;
    }


     //return y = x na a
   public static double[][] stepen(double[][] x, int a) {
        int m = x.length;
        int n = x[0].length;

        double[][] y = new double[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                y[i][j] = Math.pow(x[i][j], a);
            }
        }
        return y;
    }


    //return sigmoid
    public static double[][] sigmoid(double[][] a) {
        int m = a.length;
        int n = a[0].length;
        double[][] z = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                z[i][j] = (1.0 / (1 + Math.exp(-a[i][j])));
            }
        }
        return z;
    }

	public static double sigmoid(double x){
		return 1/(1+Math.exp(-x));
	}

    public static double[][] div(double[][] a, int b) {
        int m = a.length;
        int n = a[0].length;

        double[][] c = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = (a[i][j] / b);
            }
        }
        return c;
    }

        public static double[][] div(double[][] a, double b) {
	        int m = a.length;
	        int n = a[0].length;

	        double[][] c = new double[m][n];

	        for (int i = 0; i < m; i++) {
	            for (int j = 0; j < n; j++) {
	                c[i][j] = (a[i][j] / b);
	            }
	        }
	        return c;
    }

    public static double[][] div(double[][] a, double[][] b) {
        int m = a.length;
        int n = a[0].length;

        double c[][] = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                c[i][j] = (a[i][j] / b[i][j]);
            }
        }

        return c;
    }

    public static double greska2(int brojKlasa, int m, double[][] y, double[][] a ){
        // cross-entropy Andrei Ng
        // greska2 = -1/m * suma(Y*logA +(1-Y)log(1-A))
	        double J = 0.0;
	        for(int i = 0 ; i < m; i++){
				for(int k = 0; k < brojKlasa; k++){
					J = J+ (y[i][k]*Math.log(a[i][k]))+(1-y[i][k])*Math.log(1-a[i][k]);
				}
			}
	        return (-1.0/m) *J;
	}
	public static double[][] log(double[][] x){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[0].length; j++) {
				x[i][j] = Math.log(x[i][j]);
			}
		}
		return x;
	}

    public static double greska2(int mm, double[][] Y, double[][] A) {
        // cross-entropy
        // greska2 = -1/m * suma(Y*logA +(1-Y)log(1-A))

        int m = A.length;
        int n = A[0].length;
        double[][] z = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                //z[i][j] = (Y[i][j] * Math.log((A[i][j]))) + ((1 - Y[i][j]) * Math.log((1 - A[i][j])));
                z[i][j] = (Y[i][j] * Math.log(Math.abs(A[i][j]))) + ((1 - Y[i][j]) * Math.log(Math.abs(1 - A[i][j])));
            }
        }

        double suma = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                suma += z[i][j];
            }
        }
        double rez = -suma/mm;
        return rez;
    }

    public static double greska1(int mm, double[][] Y, double[][] A) {
        // greska1 = 1/m * suma(1/2(Y-A2)(Y-A2))

        int m = A.length;
        int n = A[0].length;
        double[][] z = new double[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                z[i][j] = (1.0/2.0)*((Y[i][j] - A[i][j])*(Y[i][j] - A[i][j]));
            }
        }

        double suma = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                suma += z[i][j];
            }
        }
        return suma/mm;
    }

    public static void stampaj(double[][] m){
		for(int i = 0; i < m.length; i++){
			for(int j = 0; j<m[0].length; j++){
				System.out.print(" " + df.format(m[i][j]) + " ");
			}
			System.out.println("");
		}
	}

    public static void stampaj(int[][] m){
		for(int i = 0; i < m.length; i++){
			for(int j = 0; j<m[0].length; j++){
				System.out.print(" " + m[i][j] + " ");
			}
			System.out.println("");
		}
	}
/////////////////////
// invertovanje matrice
public static double[][] inverzna(double a[][]) {
        int n = a.length;
        double x[][] = new double[n][n];
        double b[][] = new double[n][n];
        int index[] = new int[n];
        for (int i=0; i<n; ++i)
            b[i][i] = 1.0;

 // Transform the matrix into an upper triangle
        gaussian(a, index);

 // Update the matrix b[i][j] with the ratios stored
        for (int i=0; i<n-1; ++i)
            for (int j=i+1; j<n; ++j)
                for (int k=0; k<n; ++k)
                    b[index[j]][k]
                    	    -= a[index[j]][i]*b[index[i]][k];

 // Perform backward substitutions
        for (int i=0; i<n; ++i){
            x[n-1][i] = b[index[n-1]][i]/a[index[n-1]][n-1];
            for (int j=n-2; j>=0; --j){
                x[j][i] = b[index[j]][i];
                for (int k=j+1; k<n; ++k){
                    x[j][i] -= a[index[j]][k]*x[k][i];
                }
                x[j][i] /= a[index[j]][j];
            }
        }
        return x;
    }
    public static void gaussian(double a[][], int index[]){
        int n = index.length;
        double c[] = new double[n];

 // Initialize the index
        for (int i=0; i<n; ++i)
            index[i] = i;

 // Find the rescaling factors, one from each row
        for (int i=0; i<n; ++i){
            double c1 = 0;
            for (int j=0; j<n; ++j){
                double c0 = Math.abs(a[i][j]);
                if (c0 > c1) c1 = c0;
            }
            c[i] = c1;
        }

 // Search the pivoting element from each column
        int k = 0;
        for (int j=0; j<n-1; ++j){
            double pi1 = 0;
            for (int i=j; i<n; ++i){
                double pi0 = Math.abs(a[index[i]][j]);
                pi0 /= c[index[i]];
                if (pi0 > pi1){
                    pi1 = pi0;
                    k = i;
                }
            }

   // Interchange rows according to the pivoting order
            int itmp = index[j];
            index[j] = index[k];
            index[k] = itmp;
            for (int i=j+1; i<n; ++i){
                double pj = a[index[i]][j]/a[index[j]][j];

 // Record pivoting ratios below the diagonal
                a[index[i]][j] = pj;

 // Modify other elements accordingly
                for (int l=j+1; l<n; ++l)
                    a[index[i]][l] -= pj*a[index[j]][l];
            }
        }
    }

    public static double[][] sumByRows(double[][] x){
		double[][] rez = new double[x.length][1];
		for(int i = 0; i < x.length; i++){
			double sum = 0.0;
			for(int j = 0; j < x[0].length; j++){
				sum = sum + x[i][j];
			}
			rez[i][0] = sum/x[0].length;
		}
		return rez;
	}
/////////////////////

	public static void normalizacija1(double[][] x) {

		double zbirKvadrata = 0.0;
		for(int i = 0; i < x.length; i++){
			for(int j = 0; j<x[0].length; j++){
				zbirKvadrata = zbirKvadrata + x[i][j]*x[i][j];
			}

		}
		for(int i = 0; i < x.length; i++){
			for(int j = 0; j<x[0].length; j++){
				x[i][j] = x[i][j]*(1.0/Math.sqrt(zbirKvadrata) );
			}
		}
/*

		for(int kolona = 0; kolona < x[0].length; kolona++){
			// zbir kvadrata
			//double min = x[0][kolona];
			//double max = x[0][kolona];
			double zbirKvadrata = 0.0;
			//double mi = 0.0;
			//double s = 0.0;

			for(int i = 0; i< x.length; i++){
				zbirKvadrata = zbirKvadrata + x[i][kolona]*x[i][kolona];
			}

			for(int i = 0; i<x[0].length; i++){
				x[i][kolona] = x[i][kolona]*(1.0/Math.sqrt(zbirKvadrata) );
			}
		}
*/
	}

	public static void normalizacija2(double[][] x) {
		//MIN-MAX
		//X new = (X � Xmin) / (Xmax � Xmin)
/*
		for(int kolona = 0; kolona < x[0].length; kolona++){
			double min = x[0][kolona];
			double max = x[0][kolona];

			for(int i = 0; i< x.length; i++){
				if (x[i][kolona]> max)
				   max = x[i][kolona];
				if (x[i][kolona]< min)
				   min = x[i][kolona];
			}

			for(int i = 0; i< x.length; i++){
				x[i][kolona] = (x[i][kolona]-min)/(max-min);
			}
		}
*/
		double min = x[0][0];
		double max = x[0][0];
		for(int i = 0; i < x.length; i++){
			for(int j = 0; j< x[0].length; j++){
				if (x[i][j]> max)
				   max = x[i][j];
				if (x[i][j]< min)
				   min = x[i][j];
			}
		}

		for(int i = 0; i < x.length; i++){
			for(int j = 0; j< x[0].length; j++){
				x[i][j] = (x[i][j]-min)/(max-min);
			}
		}


	}
	public static void normalizacija(double[][] x) {
		//Z-Score
		//nG

		double min = x[0][0];
		double max = x[0][0];
		double suma = 0.0;
		double mi = 0.0;
		double s = 0.0;
		for(int i = 0; i < x.length; i++){
			for(int j = 0; j< x[0].length; j++){
				suma = suma + x[i][j];
				if (x[i][j]> max)
				   max = x[i][j];
				if (x[i][j]< min)
				   min = x[i][j];
			}
		}
		mi = suma/x.length;
		s = max-min;
		for(int i = 0; i < x.length; i++){
			for(int j = 0; j< x[0].length; j++){
				x[i][j] = (x[i][j]-mi)/s;
			}
		}
/*
		for(int kolona = 0; kolona < x[0].length; kolona++){
			double min = x[0][kolona];
			double max = x[0][kolona];
			double suma = 0.0;
			double mi = 0.0;
			double s = 0.0;

			for(int i = 0; i< x.length; i++){
				suma = suma + x[i][kolona];
				if (x[i][kolona]> max)
				   max = x[i][kolona];
				if (x[i][kolona]< min)
				   min = x[i][kolona];
			}
			mi = suma/x.length;
			s = max-min;
			for(int i = 0; i< x.length; i++){
				x[i][kolona] = (x[i][kolona]-mi)/s;
			}
		}
*/
	}

	public static void izmesajRedove(double[][] x){
		List<double[]> lista = new ArrayList<double[]>();
		lista = Arrays.asList(x);
        Collections.shuffle(lista);
        lista.toArray(x);
	}
}

