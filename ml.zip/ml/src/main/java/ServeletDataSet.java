

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import nn.*;

import java.io.BufferedReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class ServeletDataSet
 */
//@WebServlet("/ServeletDataSet1")
public class ServeletDataSet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServeletDataSet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	    JSONParser parser = new JSONParser();
	    BufferedReader reader = request.getReader();
	    JSONObject json = null;
	    try {
	    	json = (JSONObject) parser.parse(reader);
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }	    

	    JSONArray jsonMatricaUlaza = (JSONArray) json.get("matricaUlaza");
	    JSONArray jsonMatricaIzlaza = (JSONArray) json.get("matricaIzlaza");    

	    double[][] matricaUlaza = jsonArrayToMatrix(jsonMatricaUlaza);
	    double[][] matricaIzlaza = jsonArrayToMatrix(jsonMatricaIzlaza);
	    boolean normalizacijaDaNe = (boolean) json.get("normalizacijaDaNe");      
	    double procenatTest = Double.valueOf((String) json.get("procenatTest")); 
		double X[][]=null;
		double Y[][]=null;
		double X1[][]=null;
		double Y1[][]=null;
	///////////    
			if(matricaUlaza!=null && matricaIzlaza!=null){			
				int index = (int)(((double)matricaUlaza.length)*procenatTest/100.00);
				index = matricaUlaza.length-index;
				X = new double[index][matricaUlaza[0].length];
				X1 = new double[matricaUlaza.length-index][matricaUlaza[0].length];
				if(normalizacijaDaNe){
					Matrica.normalizacija(matricaUlaza);
					System.out.println("Izvrsena normalizacija ");	
				}
	            for(int i = 0; i < matricaUlaza.length; i++){
	            	for(int j = 0;j<matricaUlaza[0].length; j++){
		            	if (i<index){
		            		X[i][j]=matricaUlaza[i][j];            		
		            	}else{
		            		X1[i-index][j]=matricaUlaza[i][j]; 
		            	}
	            	}            	
	            }
				Y = new double[index][matricaIzlaza[0].length];
				Y1 = new double[matricaUlaza.length-index][matricaIzlaza[0].length];

	            for(int i = 0; i < matricaIzlaza.length; i++){
	            	for(int j = 0;j<matricaIzlaza[0].length; j++){
		            	if (i<index){
		            		Y[i][j]=matricaIzlaza[i][j];            		
		            	}else{
		            		Y1[i-index][j]=matricaIzlaza[i][j]; 
		            	}
	            	}            	
	            }            	 		
	        }    
			////////// 
			request.getSession().setAttribute("matricaUlaza", matricaUlaza);
			request.getSession().setAttribute("matricaIzlaza", matricaIzlaza);
			request.getSession().setAttribute("normalizacijaDaNe", normalizacijaDaNe);
			request.getSession().setAttribute("procenatTest", procenatTest); 
			    
			request.getSession().setAttribute("X", X);
			request.getSession().setAttribute("Y", Y);
			request.getSession().setAttribute("X1", X1);
			request.getSession().setAttribute("Y1", Y1);    
	    
			response.getWriter().write("Data has been loaded!!!");
	}
	private double[][] jsonArrayToMatrix(JSONArray jsonArray) {
        double[][] matrix = new double[jsonArray.size()][];
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONArray jsonRow = (JSONArray) jsonArray.get(i);
            double[] row = new double[jsonRow.size()];
            for (int j = 0; j < jsonRow.size(); j++) {
                row[j] = Double.parseDouble(jsonRow.get(j).toString());
            }
            matrix[i] = row;
        }
        return matrix;
    }
}
