// Nenad Jovanovic
// 29.12.2023.

document.addEventListener('DOMContentLoaded', (event) => {

		window.onload = function() {
	    	repaint();
	    };
		var listaTezina = [];
		var matriceTezine = [];
		var prikaziTezine=false;
		//var matriceTezine = [];
	
		var networkDiv = document.createElement("div");
		networkDiv.id = "networkDiv";
		var canvas = document.createElement("canvas");
		canvas.id = "myCanvas";
		canvas.height = 3;
		canvas.width = 700;		
		networkDiv.appendChild(canvas);		
		var canvasContainer = document.getElementById("canvas-container");		
		canvasContainer.appendChild(networkDiv);
		  
		const ctx = canvas.getContext('2d', { willReadFrequently: true }); 
		 	
	//const canvas = document.getElementById('myCanvas');
	//const ctx = canvas.getContext('2d');	 

	var neurons = [];
	let draggingNeuron = null;
	let dragOffsetX, dragOffsetY;
	let conectionColor = 'blue';
	
	function drawConnection(fromNeuron, toNeuron, weight) {		
		ctx.beginPath();
		ctx.moveTo(fromNeuron.x, fromNeuron.y);
		ctx.lineTo(toNeuron.x, toNeuron.y);
		ctx.strokeStyle = conectionColor;
		ctx.fill();
		ctx.stroke();
	
		// Draw weight
		const midX = (fromNeuron.x + toNeuron.x) / 2;
		const midY = (fromNeuron.y + toNeuron.y) / 2;
		ctx.fillStyle = 'blue';
		if(prikaziTezine)
			ctx.fillText(weight.toFixed(2), midX, midY);
	}
	
	function drawNeuron(neuron) {
		ctx.beginPath();
		ctx.arc(neuron.x, neuron.y, neuron.radius, 0, Math.PI * 2, true);
		ctx.fillStyle = neuron.color;
		ctx.fill();
		ctx.stroke();
	
		// Draw input/output
		const neuronSize = Number(document.getElementById('neuronSize').value);
		ctx.fillStyle = 'blue';
		//ctx.fillText(neuron.input.toFixed(3), neuron.x - 10, neuron.y - 15);
		if(neuron.layer==0)
			ctx.fillText(neuron.input, neuron.x, neuron.y - neuronSize / 2 - 5);
		ctx.fillStyle = 'green';
		var konfiguracija = document.getElementById('networkConfig').value.split(',').map(Number);
		if(neuron.layer==(konfiguracija.length-1))
			ctx.fillText(neuron.output.toFixed(3), neuron.x, neuron.y + neuronSize / 2 + 10);
	}
	
	function drawNetwork() {	 	 			
		var slojevi = document.getElementById('networkConfig').value.split(',').map(Number);
		if(matriceTezine!=null){
			listaTezina = matriceTezine;	
		}			
		if(listaTezina.length === 0){
			for(let k = 0; k < slojevi.length-1; k++){
				let w =[];
				for(let i =0; i < slojevi[k];i++){
					w[i] =[];
					for(let j =0; j < slojevi[k+1];j++){
						w[i][j] = 0.0;
					}				
				}
				listaTezina[k] = w;
			}			
		}	
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		// Assuming each neuron is connected to every neuron in the next layer
		for (let i = 0; i < neurons.length - 1; i++) {
			if (listaTezina.length > 0) {
				let w1 = listaTezina[neurons[i].layer];
				for (let j = i + 1; j < neurons.length; j++) {
					if (neurons[i].layer + 1 == neurons[j].layer) {
						drawConnection(neurons[i], neurons[j], w1[neurons[i].index][neurons[j].index]);
					}
				}
			}
		}
	
		neurons.forEach(neuron => {
			drawNeuron(neuron);
		});
	}
	
	canvas.addEventListener('mousedown', function(e) {
		const rect = canvas.getBoundingClientRect();
		const x = e.clientX - rect.left;
		const y = e.clientY - rect.top;
		draggingNeuron = neurons.find(neuron => Math.hypot(neuron.x - x, neuron.y - y) < neuron.radius);
		if (draggingNeuron) {
			dragOffsetX = draggingNeuron.x - x;
			dragOffsetY = draggingNeuron.y - y;
		}
	});
	
	canvas.addEventListener('mousemove', function(e) {
		if (draggingNeuron) {
			const rect = canvas.getBoundingClientRect();
			draggingNeuron.x = e.clientX - rect.left + dragOffsetX;
			draggingNeuron.y = e.clientY - rect.top + dragOffsetY;
			drawNetwork();
		}
	});
	
	canvas.addEventListener('mouseup', function() {
		draggingNeuron = null;
	});
	
	document.getElementById('neuronSize').addEventListener('input', function() {
		document.getElementById('neuronSizeOutput').textContent = this.value;
		const neuronSize = Number(document.getElementById('neuronSize').value);
		for (let i = 0; i < neurons.length; i++) {
			neurons[i].radius = neuronSize / 2
		}
		drawNetwork();
	});
	
	document.getElementById('neuronColor').addEventListener('input', function() {
		const neuronColor = document.getElementById('neuronColor').value;
		for (let i = 0; i < neurons.length; i++) {
			neurons[i].color = neuronColor
		}
		drawNetwork();
	});
	
	document.getElementById('learningRate').addEventListener('input', function() {
		document.getElementById('learningRateOutput').textContent = this.value;
	});
	
	document.getElementById('conectionColor').addEventListener('input', function() {
		conectionColor = document.getElementById('conectionColor').value;
		drawNetwork();
	});
	
	document.getElementById('trening').addEventListener('click', function(event) {
		event.preventDefault()		
		var a = document.getElementById('numberEpoch').value;
		if (a == null || a == "" || a == " ") {
		      alert("Unesi alfa!");
		      return;
		}
		if(matriceTezine!=null){
			listaTezina = matriceTezine;	
		}	
		trening();
		drawNetwork();				
	});
	
	document.getElementById('networkConfig').addEventListener('change', function(e) {				
		var can = document.getElementById("myCanvas");
		can.height = 500;
		can.width = 700;	
		listaTezina = [];
		matriceTezine = []							
		const layerCounts = e.target.value.split(',').map(Number);
		updateTransferFunctionSelectors(layerCounts.length-2);
		repaint();
	});
	
	function getTransferFunctions(layerCount) {
		let transferFunctions = [];
		for (let i = 0; i < layerCount; i++) {
			let select = document.getElementById(`transferFunction${i + 1}`);
			transferFunctions.push(select ? select.value : 'linear');
		}
		return transferFunctions;
	}
	
	function updateTransferFunctionSelectors(layerCount) {
		const container = document.getElementById('transferFunctionContainer');
		container.innerHTML = '';
		for (let i = 1; i <= (layerCount); i++) {
			var noviDiv = document.createElement('div');
			noviDiv.className = 'flex-container';
			const label = document.createElement('label');
			label.htmlFor = `transferFunction${i}`;
			label.textContent = `Layer ${i}:`;
	
			const select = document.createElement('select');
			select.id = `transferFunction${i}`;
			select.name = `transferFunction${i}`;
			['SIGLOG', 'TANH', 'LINEAR'].forEach(function(fn) {
				const option = document.createElement('option');
				option.value = fn.toLowerCase();
				option.textContent = fn;
				select.appendChild(option);
			});
			noviDiv.appendChild(label);		
			noviDiv.appendChild(select);
			container.appendChild(noviDiv);
		}
	}

	function trening() {	
		var konfiguracija = document.getElementById('networkConfig').value.split(',').map(Number);		
		var learningRate = document.getElementById('learningRate').value;
		var errorType = document.querySelector('input[name="error"]:checked').value;
		var numberEpoch = document.getElementById('numberEpoch').value;		
		var transferFunctionValues = getTransferFunctionValues(konfiguracija.length-2);
		
		var podaciZaSlanje = {
		    ...transferFunctionValues,
		    learningRate: learningRate,
		    errorType: errorType,
		    numberEpoch: numberEpoch,
		    konfiguracija: konfiguracija
		};
					
		var jsonPodaci = JSON.stringify(podaciZaSlanje);					
		//AJAX poziv
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'ServeletNNTrening', true); // Ovde koristimo 'trening.jsp' umesto servleta
		xhr.setRequestHeader('Content-Type', 'application/json');
	
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				document.getElementById('textInput').value = xhr.responseText;
			}
		};
		xhr.send(jsonPodaci);
	}	

	function getTransferFunctionValues(layerCount1) {
	    var values = {};
	    for (let i = 1; i <= layerCount1; i++) {
	        var selectElement = document.getElementById(`transferFunction${i}`);
	        if (selectElement) {
	            values[`transferFunction${i}`] = selectElement.value;
	        }
	    }
	    return values;
	}	

	function repaint() {
		event.preventDefault();
		var layerValues = document.getElementById('networkConfig').value.split(',').map(Number);
		var neuronSize = Number(document.getElementById('neuronSize').value);
		var neuronColor = document.getElementById('neuronColor').value; 
		
		if(layerValues.length > 0){
		updateTransferFunctionSelectors(layerValues.length-2);		   	
		neurons = [];
		//let yGap = canvas.height / (layerValues.length + 1);
		let yGap = (canvas.height-100) / (layerValues.length-1);
		layerValues.forEach((size, layerIndex) => {
			let xGap = canvas.width / (size + 1);
			for (let i = 1; i <= size; i++) {
				neurons.push({
					x: xGap * i,
					//y: yGap * (layerIndex +1),
					y: 50+ yGap * (layerIndex),
					radius: neuronSize / 2,
					color: neuronColor,
					layer: layerIndex,
					input: layerIndex,
					output: 0,
					index: (i - 1),
				});
			}			
		});
		drawNetwork();			
		}
	}	
	
    document.getElementById('dataset').addEventListener('click', function() {		
			var iframe = document.getElementById('iframeData');			
            //var iframe = document.createElement('iframe');
            iframe.src = 'excel.html'; // 
            iframe.style.height = '200';
            iframe.style.width = '700';         
           // iframe.style.border = '1';

            var container = document.getElementById('dataDiv');  
            // Očisti prethodni sadržaj kontejnera ako je potrebno
            container.innerHTML = '';
            container.style.display = 'block'; // Prikazuje kontejner
            container.appendChild(iframe); // Dodaje iframe u kontejner           
    });

	window.addEventListener('message', function(event) {
	    // Ovde možete dodati provere za `event.origin` radi sigurnosti
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeData');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});       

	tezine.addEventListener('change', function() {
		    if (this.checked) {
				prikaziTezine=true;
////////////
			    var xhr = new XMLHttpRequest();
			    xhr.open('GET', 'ServeletNNTezine', true);	// tezine.jsp
			    xhr.onreadystatechange = function() {
			        if (xhr.readyState == 4 && xhr.status == 200) {
						matriceTezine = JSON.parse(xhr.responseText);	
						if(matriceTezine!=null){
							listaTezina = matriceTezine;	
							repaint();									
					    } else {
					       prikaziTezine=false;	
					       listaTezina = [];	
						   repaint();						       			       
					    }							           
					}
		    	};
		    	xhr.send();   
			} else{
				prikaziTezine=false;	
				listaTezina = [];	
				repaint();						       			       
				drawNetwork();	
			}
	});   
		
	document.getElementById('greskaTrening').addEventListener('click', function(event) {	
        event.preventDefault()	
//////////
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', 'ServeletNNGrafTrening', true);	// grafTrening.jsp
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
				var matricaTreninga = JSON.parse(xhr.responseText);
				var canvas = document.getElementById('grafGreske');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });		
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				} 		
				//var matrica = matricaTreninga;
				var labels = []; // Labels za X osu
				var data1 = []; // Podaci za prvu kolonu
				var data2 = []; // Podaci za drugu kolonu
				
				for (var i = 0; i < matricaTreninga.length; i++) {
				    labels.push(i + 1); // Ako imate specifične oznake, dodajte ih ovde
				    data1.push(matricaTreninga[i][0]);
				    data2.push(matricaTreninga[i][1]);
				}
		
				window.grafGreske = new Chart(ctx, {
				    type: 'line', // Možete promeniti tip grafikona (npr. 'bar', 'line')
				    data: {
				        labels: labels,
				        datasets: [{
				            label: 'Stvarni podaci',
				            data: data1,
				            backgroundColor: 'rgba(255, 99, 132, 0.2)',
				            borderColor: 'rgba(255, 99, 132, 1)',
				            borderWidth: 1
				        }, {
				            label: 'Predvidjeni',
				            data: data2,
				            backgroundColor: 'rgba(54, 162, 235, 0.2)',
				            borderColor: 'rgba(54, 162, 235, 1)',
				            borderWidth: 1
				        }]
				    },
					options: {
					    responsive: false,
					    plugins: {
					        title: {
					            display: true,
					            text: 'Performance Ratio - Training',
					            font: {
					                size: 18
					            },
					            color: '#333'
					        }
					    },
					    scales: {
					        y: {
					            beginAtZero: true
					        }
					    }
					}
				});  					            
			}
    	};
    	xhr.send();           		
        document.getElementById('graphDiv').style.display = 'block'           
	});			  			
		  		  
	document.getElementById('grafTest').addEventListener('click', function(event) {	
        event.preventDefault()		
////////
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', 'ServeletNNGrafTest', true);	// grafTest.jsp
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
				var matricaTest = JSON.parse(xhr.responseText);
				var canvas = document.getElementById('grafGreske');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });		
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				} 		
				var labels = []; // Labels za X osu
				var data1 = []; // Podaci za prvu kolonu
				var data2 = []; // Podaci za drugu kolonu
				
				for (var i = 0; i < matricaTest.length; i++) {
				    labels.push(i + 1); // Ako imate specifične oznake, dodajte ih ovde
				    data1.push(matricaTest[i][0]);
				    data2.push(matricaTest[i][1]);
				}
				window.grafGreske = new Chart(ctx, {
				    type: 'line', // Možete promeniti tip grafikona (npr. 'bar', 'line')
				    data: {
				        labels: labels,
				        datasets: [{
				            label: 'Stvarni podaci',
				            data: data1,
				            backgroundColor: 'rgba(255, 99, 132, 0.2)',
				            borderColor: 'rgba(255, 99, 132, 1)',
				            borderWidth: 1
				        }, {
				            label: 'Predvidjeni',
				            data: data2,
				            backgroundColor: 'rgba(54, 162, 235, 0.2)',
				            borderColor: 'rgba(54, 162, 235, 1)',
				            borderWidth: 1
				        }]
				    },
					options: {
					    responsive: false,
					    plugins: {
					        title: {
					            display: true,
					            text: 'Performance Ratio - Test',
					            font: {
					                size: 18
					            },
					            color: '#333'
					        }
					    },
					    scales: {
					        y: {
					            beginAtZero: true
					        }
					    }
					}
					
				});  	  				 					
            
			}
    	};
    	xhr.send();           		
        document.getElementById('graphDiv').style.display = 'block'          
        
	});	
			  			
	document.getElementById('greska').addEventListener('click', function(event) {	
        event.preventDefault()	
		///trazim niz od nizGreske.jsp
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', 'GrafGreskeServlet', true);	
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
	            var nizGreske1 = JSON.parse(xhr.responseText);
				var canvas = document.getElementById('grafGreske');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   
				window.grafGreske = new Chart(ctx, {	
			        type: 'line', // Tip grafa, može biti 'bar', 'line' itd.
			        data: {
			            labels: nizGreske1.map((_, i) => i + 1), // Oznake za X osu
			            datasets: [{
			                label: 'ERROR',
			                data: nizGreske1, // Vaši podaci
			                backgroundColor: 'rgba(255, 99, 132, 0.2)',
			                borderColor: 'rgba(255, 99, 132, 1)',
			                borderWidth: 1,
			                pointRadius: 1
			            }]
			        },
			        options: {
						responsive: false,
			            scales: {
			                y: 	{
			                    beginAtZero: true
			                }
			            }
			        }
			    });            
			}
    	};
    	xhr.send();   
	    document.getElementById('graphDiv').style.display = 'block'
	});	
		
	document.getElementById('prepoznavanje').addEventListener('click', function(event) {	
        event.preventDefault()	
        
		// Kreiranje div elementa sa klasom 'toolbar'
		var toolbarDiv = document.createElement("div");
		toolbarDiv.className = "toolbar";
		
		// Dodavanje labela i inputa za boju
		var colorLabel = document.createElement("label");
		colorLabel.textContent = "Color: ";
		var colorPicker = document.createElement("input");
		colorPicker.type = "color";
		colorPicker.id = "colorPicker";
		colorPicker.value = "#0000ff";
		colorLabel.appendChild(colorPicker);
		toolbarDiv.appendChild(colorLabel);
		
		// Dodavanje labela i inputa za debljinu linije
		var lineWidthLabel = document.createElement("label");
		lineWidthLabel.textContent = "Line width: ";
		var lineWidthInput = document.createElement("input");
		lineWidthInput.type = "range";
		lineWidthInput.id = "lineWidth";
		lineWidthInput.min = "1";
		lineWidthInput.max = "10";
		lineWidthInput.value = "1";
		lineWidthLabel.appendChild(lineWidthInput);
		toolbarDiv.appendChild(lineWidthLabel);
		
		// Dodavanje dugmadi
		var zoomButton = document.createElement("button");
		zoomButton.id = "zoomButton";
		zoomButton.textContent = "ZOOM";
		toolbarDiv.appendChild(zoomButton);
		
		var convertButton = document.createElement("button");
		convertButton.id = "convertButton";
		convertButton.textContent = "CONVERT";
		toolbarDiv.appendChild(convertButton);
		
		var deleteButton = document.createElement("button");
		deleteButton.id = "deleteButton";
		deleteButton.textContent = "DELETE";
		toolbarDiv.appendChild(deleteButton);
		
		var addButton = document.createElement("button");
		addButton.id = "addButton";
		addButton.textContent = "Load Data";
		toolbarDiv.appendChild(addButton);		
		
		var prepoznajButton = document.createElement("button");
		prepoznajButton.id = "prepoznajButton";
		prepoznajButton.textContent = "Recognize";
		toolbarDiv.appendChild(prepoznajButton);		
		
		// Kreiranje div elementa sa klasom 'container'
		var containerDiv = document.createElement("div");
		containerDiv.className = "container";
		
		// Dodavanje canvasa
		var drawingCanvas = document.createElement("canvas");		
		drawingCanvas.id = "drawingCanvas";
		//drawingCanvas.height = "300";
		//drawingCanvas.width = "700";

		containerDiv.appendChild(drawingCanvas);
		
		// Dodavanje pre elementa
		var matrixOutput = document.createElement("pre");
		matrixOutput.id = "matrixOutput";
		containerDiv.appendChild(matrixOutput);
		
		
		//divPrepoznavanje
		var divPrepoznavanje = document.createElement("div");
		divPrepoznavanje.id = "divPrepoznavanje";
		divPrepoznavanje.style.width = '700px';
		divPrepoznavanje.style.height = '500px';		
		
		divPrepoznavanje.appendChild(toolbarDiv);
		divPrepoznavanje.appendChild(containerDiv);			
		// Dodavanje toolbar i container divova u body dokumenta ili neki drugi roditeljski element
		
		
		var canvasContainer = document.getElementById("canvas-container");		 
		canvasContainer.appendChild(divPrepoznavanje); 			
		
	    // Dinamičko dodavanje <script> taga
	    var script = document.createElement('script');
	    script.src = 'prepoznavanje.js'; // Postavite putanju do vaše JavaScript datoteke
	    script.onload = function() {
	        // Ovaj kod će se izvršiti nakon što se skripta učita
	        console.log('Skripta je učitana');
	    };
	    document.body.appendChild(script);	     		
	});	
	
	document.getElementById('start').addEventListener('click', function() {	
		var konfiguracija = document.getElementById('networkConfig').value.split(',').map(Number);		
		var brojUlaza = konfiguracija[0];		
	 	var doubleNiz = []; 
	 	
	 	for(let i=0;i<brojUlaza;i++){
			  let unos = prompt("Ulaz:"+i, "");
			  if(unos!=null){
				 doubleNiz.push(unos); 
			  }
		}
	    var jsonDoubleNiz = JSON.stringify(doubleNiz); // Konvertovanje niza u JSON
	
	    // Kreiranje AJAX zahteva
	    var xhr = new XMLHttpRequest();
	    xhr.open("POST", "nn/ServeletNNStart", true); // start.jsp
	    xhr.setRequestHeader("Content-Type", "application/json");
	
	    // Definisanje funkcije koja će biti pozvana kada se zahtev završi
	    xhr.onreadystatechange = function() {
	        if (this.readyState == 4 && this.status == 200) {
	            // Obrada odgovora
	            var rez = JSON.parse(xhr.responseText);
 
	            var i1 = 0;
	            var i2 = 0;
	            for (let i = 0; i < neurons.length; i++) {
					if(neurons[i].layer == 0){
						neurons[i].input=doubleNiz[i1++];
						drawNeuron(neurons[i]);
					}
					if(neurons[i].layer == konfiguracija.length-1){
						neurons[i].output=rez[i2++][0];
						drawNeuron(neurons[i]);
					}				
				}
				var prikaz = document.getElementById('textInput').value;
            	document.getElementById('textInput').value = prikaz + "\n\nZa ulaz ["+ doubleNiz+ "]\nrezultat je [" + rez+"]";
	        }
	    };
	
	    // Slanje zahteva sa JSON nizom
	    xhr.send(jsonDoubleNiz);

	});
		

});
