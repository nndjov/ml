document.addEventListener('DOMContentLoaded', (event) => {   
	 
    document.getElementById('dataset').addEventListener('click', function() {		
			var iframe = document.getElementById('iframeData');					
            //var iframe = document.createElement('iframe');
            iframe.src = 'excel.html'; // 
            iframe.style.height = '100';
            iframe.style.width = '700';				
            iframe.src = 'excel.html'; // 

            var container = document.getElementById('dataDiv');  

            container.innerHTML = '';
            container.style.display = 'block'; // Prikazuje kontejner
            container.appendChild(iframe); // Dodaje iframe u kontejner           
    });
    
	window.addEventListener('message', function(event) {
	    // Ovde možete dodati provere za `event.origin` radi sigurnosti
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeData');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});



   // Funkcija za AJAX zahtev
    function getLinRegData() {
        // Napravite AJAX zahtev ka Servletu
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'ServeletGrafLinReg', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Dobijanje podataka iz odgovora
                var response = JSON.parse(xhr.responseText);
                var matricaUlaza = response.matricaUlaza;
                var matricaIzlaza = response.matricaIzlaza;               
			    var matrica = [];			
			    // Spajamo matrice
			    for (var i = 0; i < matricaUlaza.length; i++) {
			        matrica.push([matricaUlaza[i][0], matricaIzlaza[i][0]]);
			    }                
                // Iscrtavanje podataka u grafikonu

				var canvas = document.getElementById('grafPodaciPrikaz');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   

            //new Chart(ctx, {
			window.grafGreske = new Chart(ctx, {	
                type: 'scatter',
                data: {
                    datasets: [{
                        label: 'Scatter Plot',
                        data: matrica.map(function (row) {
                            return { x: row[0], y: row[1] };
                        }),
                        backgroundColor: 'rgba(75, 192, 192, 0.8)',
                        pointRadius: 5,
                        pointHoverRadius: 8,
                    }]
                },
                options: {
                    scales: {
                        x: {
                            type: 'linear',
                            position: 'bottom'
                        },
                        y: {
                            type: 'linear',
                            position: 'left'
                        }
                    }
                }
            });
//
            }
        };
        xhr.send();
    }


	document.getElementById('grafPodaci').addEventListener('click', function(event) {	
        event.preventDefault()	

	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv);         
        
        getLinRegData();
    });	

   document.getElementById('treningLinReg').addEventListener('click', function() {				
		var numEpoch = document.getElementById('numEpoch').value;
		var learningRate = document.getElementById('learningRate').value;
		var lambda = document.getElementById('lambda').value;
		var tolerance = document.getElementById('tolerance').value;			
		//var reg_type = document.getElementById('reg_type').value;
		var reg_type = document.querySelector('input[name="reg_type"]:checked').value;	
					
		var podaciZaSlanje = {
		    numEpoch: numEpoch,
		    learningRate: learningRate,
		    lambda: lambda,
		    tolerance: tolerance,
		    reg_type: reg_type		        		    
	    };
		
		console.log(podaciZaSlanje);
					
		var jsonPodaci = JSON.stringify(podaciZaSlanje);	
		//var jsonPodaci = prepareDataForAjax(podaciZaSlanje);
						
		//AJAX poziv
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'ServeletTreningLiReg', true); // Moze da se koristi i 'trening.jsp' umesto servleta
		xhr.setRequestHeader('Content-Type', 'application/json');
	
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				document.getElementById('textInput').value += "\n\n"+xhr.responseText;
			}
		};
		xhr.send(jsonPodaci);         
    });

	document.getElementById('grafGreske').addEventListener('click', function(event) {	
        event.preventDefault()	
        
	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv); 
	            
		///trazim niz od nizGreske.jsp
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', 'ServeletGrafGreske', true);	
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
	            var nizGreske1 = JSON.parse(xhr.responseText);
				var canvas = document.getElementById('grafPodaciPrikaz');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   
				window.grafGreske = new Chart(ctx, {	
			        type: 'line', // Tip grafa, može biti 'bar', 'line' itd.
			        data: {
			            labels: nizGreske1.map((_, i) => i + 1), // Oznake za X osu
			            datasets: [{
			                label: 'ERROR',
			                data: nizGreske1, // Vaši podaci
			                backgroundColor: 'rgba(255, 99, 132, 0.2)',
			                borderColor: 'rgba(255, 99, 132, 1)',
			                borderWidth: 1,
			                pointRadius: 1
			            }]
			        },
			        options: {
						responsive: false,
			            scales: {
			                y: 	{
			                    beginAtZero: true
			                }
			            }
			        }
			    });            
			}
    	};
    	xhr.send();   
	    document.getElementById('grafPodaciPrikaz').style.display = 'block'
	});	
	
	
	document.getElementById('regresijaGraf').addEventListener('click', function(event) {	
        event.preventDefault()	
        
	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv);         
//////////////////
       var xhr = new XMLHttpRequest();
       var ctx;
        xhr.open('GET', 'ServeletGrafLinija', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Dobijanje podataka iz odgovora
                var response = JSON.parse(xhr.responseText);
                var matricaUlaza = response.matricaUlaza;
                var matricaIzlaza = response.matricaIzlaza;  
                var koeficijenti  = response.koeficijenti;          
			    var matrica = [];			
			    // Spajamo matrice
			    for (var i = 0; i < matricaUlaza.length; i++) {
			        matrica.push([matricaUlaza[i][0], matricaIzlaza[i][0]]);
			    }                
                // Iscrtavanje podataka u grafikonu

				var canvas = document.getElementById('grafPodaciPrikaz');
				ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   
        		var b0 = koeficijenti[0];
       			var b1 = koeficijenti[1];
       			
	            //new Chart(ctx, {
				window.grafGreske = new Chart(ctx, {	
	                type: 'scatter',
	                data: {
	                    datasets: [{
	                        label: 'Data',
	                        data: matrica.map(function (row) {
	                            return { x: row[0], y: row[1] };
	                        }),
	                        backgroundColor: 'rgba(75, 192, 192, 0.8)',
	                        pointRadius: 5,
	                        pointHoverRadius: 8,
	                    },
				        {
				                type: 'line',
				                label: 'Linear Regression',
				                data: [{ x: Math.min(...matricaUlaza) -(Math.max(...matricaUlaza)-Math.min(...matricaUlaza))/12, y: b0 + b1 * Math.min(...matricaUlaza) },
				                       { x: Math.max(...matricaUlaza)+(Math.max(...matricaUlaza)-Math.min(...matricaUlaza))/12, y: b0 + b1 * Math.max(...matricaUlaza) }],
				                borderColor: 'red',
				                borderWidth: 5,
				                fill: false,
				         }	                    
	                  ]
	                },	                
	                options: {
	                    scales: {
	                        x: {
	                            type: 'linear',
	                            position: 'bottom'
	                        },
	                        y: {
	                            type: 'linear',
	                            position: 'left'
	                        }
	                    }
	                }	                
	            });

            }          
        };

        xhr.send();
///////////////        
    });	
    
	
    document.getElementById('useModel').addEventListener('click', function() {
		var iframe1 = document.createElement('iframe');
		iframe1.id = 'iframeUse';
	    iframe1.style.width = '700px';
	    iframe1.style.height = '100px';
	    iframe1.src = 'useModelLinReg.html'; 
	    		
        var useDiv = document.getElementById('useDiv');  
        // Očisti prethodni sadržaj kontejnera ako je potrebno
        useDiv.innerHTML = '';
        useDiv.style.display = 'block'; // Prikazuje kontejner
        useDiv.appendChild(iframe1);     
        //var container = document.getElementById('canvas-container');
        //container.appendChild(useDiv);  
    });	

	window.addEventListener('message', function(event) {	    
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeUse');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});     
    
//////////
	document.getElementById('cachesize').addEventListener('input', function() {
		document.getElementById('cachesizeOutput').textContent = this.value;
	});    
///////////
	// primam rezultat od useModel.html
	window.addEventListener('message', function(event) {
	    // Možete dodati proveru event.origin ovde za dodatnu sigurnost
	    if (event.data.key === 'vred') {
	        //alert("Nova vrednost: " + event.data.value);
	        document.getElementById('textInput').value += "\n"+event.data.value;
	    }
	}, false);    		
	
});       