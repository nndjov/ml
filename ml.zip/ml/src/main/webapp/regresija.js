	//document.getElementById('learningRateR').addEventListener('input', function() {
	//    document.getElementById('learningRateROutput').textContent = this.value;
	//});

    document.getElementById('dataset').addEventListener('click', function() {		
			var iframe = document.getElementById('iframeData');			
            //var iframe = document.createElement('iframe');
            iframe.src = 'excel.html'; // Zamenite sa pravim URL-om druge stranice
           //iframe.style.height = '500';
           //iframe.style.width = '650';         
           // iframe.style.border = '1';

            var container = document.getElementById('dataDiv');  
            // Očisti prethodni sadržaj kontejnera ako je potrebno
            container.innerHTML = '';
            container.style.display = 'block'; // Prikazuje kontejner
            container.appendChild(iframe); // Dodaje iframe u kontejner           
    });
    
	document.getElementById('logReg').addEventListener('click', function() {		
		var networkDiv = document.createElement("div");
		networkDiv.id = "networkDiv";
		networkDiv.style.width = '700px';
		networkDiv.style.height = '500px';		
		var textInputR = document.createElement("textarea");
		textInputR.id = "textInputR";
		textInputR.style.height = '500px';
		textInputR.style.width = '700px';	
		networkDiv.appendChild(textInputR);		
		var canvasContainer = document.getElementById("canvas-container");		
		canvasContainer.appendChild(networkDiv); 		
//////		
		var learningRate = document.getElementById('learningRateR').value;
		var numberEpoch = document.getElementById('numberEpochR').value;
		
		var podaciZaSlanje = {
		    learningRate: learningRate,
		    numberEpoch: numberEpoch,
		};
		
		console.log('hello');
		console.log(podaciZaSlanje);
					
		var jsonPodaci = JSON.stringify(podaciZaSlanje);						
		//AJAX poziv
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'logreg.jsp', true); // 
		xhr.setRequestHeader('Content-Type', 'application/json');
	
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				document.getElementById('textInputR').value = xhr.responseText;
			}
		};
		xhr.send(jsonPodaci);	
//////			
	});   

	document.getElementById('greskaGraf').addEventListener('click', function(event) {	
        event.preventDefault()	
		///trazim niz od nizGreske.jsp
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', 'grafGreskeReg.jsp', true);	
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
	            var nizGreske1 = JSON.parse(xhr.responseText);
				var canvas = document.getElementById('grafGreskeR');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   
				window.grafGreske = new Chart(ctx, {	
			        type: 'line', // Tip grafa, može biti 'bar', 'line' itd.
			        data: {
			            labels: nizGreske1.map((_, i) => i + 1), // Oznake za X osu
			            datasets: [{
			                label: 'ERROR',
			                data: nizGreske1, // Vaši podaci
			                backgroundColor: 'rgba(255, 99, 132, 0.2)',
			                borderColor: 'rgba(255, 99, 132, 1)',
			                borderWidth: 1,
			                pointRadius: 1
			            }]
			        },
			        options: {
						responsive: false,
			            scales: {
			                y: 	{
			                    beginAtZero: true
			                }
			            }
			        }
			    });            
			}
    	};
    	xhr.send();   
	    document.getElementById('graphDiv').style.display = 'block'
	});	