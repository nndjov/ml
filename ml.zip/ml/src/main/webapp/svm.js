  
document.addEventListener('DOMContentLoaded', (event) => {   
	window.myChart = null;  
	 
    document.getElementById('dataset').addEventListener('click', function() {		
			var iframe = document.getElementById('iframeData');					
            //var iframe = document.createElement('iframe');
            iframe.src = 'excel.html'; // 
            iframe.style.height = '100';
            iframe.style.width = '700';				
            iframe.src = 'excel.html'; // 

            var container = document.getElementById('dataDiv');  

            container.innerHTML = '';
            container.style.display = 'block'; // Prikazuje kontejner
            container.appendChild(iframe); // Dodaje iframe u kontejner           
    });
    
	window.addEventListener('message', function(event) {
	    // Ovde možete dodati provere za `event.origin` radi sigurnosti
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeData');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});     
    
    document.getElementById('treningSvm').addEventListener('click', function() {				
		var svm_type = document.getElementById('svm_type').value;
		var kernel_type = document.getElementById('kernel_type').value;
		var cost = document.getElementById('cost').value;
		var gamma = document.getElementById('gamma').value;	
		var probability = document.querySelector('input[name="probability"]:checked').value;
		var cachesize = document.getElementById('cachesize').value;
		var epsilon = document.getElementById('epsilon').value;	
		var nu = document.getElementById('nu').value;
		var coef0 = document.getElementById('coef0').value;
		var degree = document.getElementById('degree').value;		
			
		var podaciZaSlanje = {
		    svm_type: svm_type,
		    kernel_type: kernel_type,
		    cost: cost,
		    gamma: gamma,
		    probability: probability,
		    cachesize: cachesize,
		    epsilon: epsilon,
		    nu: nu,
		    coef0: coef0,
		    degree: degree		    		    
		    };
		
		console.log(podaciZaSlanje);
					
		var jsonPodaci = JSON.stringify(podaciZaSlanje);	
		//var jsonPodaci = prepareDataForAjax(podaciZaSlanje);
						
		//AJAX poziv
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'ServeletTreningSvm', true); // Moze da se koristi i 'trening.jsp' umesto servleta
		xhr.setRequestHeader('Content-Type', 'application/json');
	
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				document.getElementById('textInput').value += "\n\n"+xhr.responseText;
			}
		};
		xhr.send(jsonPodaci);         
    });
    
 //////////   

	document.getElementById('grafPodaci').addEventListener('click', function(event) {	
        event.preventDefault()	
	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv);  	    
	          
		var xhr = new XMLHttpRequest();
		xhr.open('GET', 'ServeletGrafPodaci', true);		// grafPodaci.jsp
		xhr.onload = function() {
		    if (xhr.status >= 200 && xhr.status < 300) {
		        // Parsiranje odgovora u JSON formatu
		        const podaci = JSON.parse(xhr.responseText);
		
		        // Ekstrakcija podataka za crtanje grafikona
		        const podaciZaGrafikon = podaci.map(function(d) {
		            return { x: d[0], y: d[1], klasa: d[2] };
		        });
		
		        // Podela podataka na dve klase
		        const klasa1 = podaciZaGrafikon.filter(p => p.klasa === 1);
		        const klasa0 = podaciZaGrafikon.filter(p => p.klasa === 0);
		
		        // Konfiguracija za Chart.js
		        const config = {
		            type: 'scatter',
		            data: {
		                datasets: [{
		                    label: 'Klasa 1',
		                    data: klasa1,
		                    backgroundColor: 'rgba(255, 99, 132, 1)',
		                }, {
		                    label: 'Klasa 0',
		                    data: klasa0,
		                    backgroundColor: 'rgba(54, 162, 235, 1)',
		                }]
		            },
		            options: {
		                scales: {
		                    x: {
		                        title: {
		                            display: true,
		                            text: 'X vrednost'
		                        }
		                    },
		                    y: {
		                        title: {
		                            display: true,
		                            text: 'Y vrednost'
		                        }
		                    }
		                }
		            }
		        };
		
		        // Dobavljanje canvas elementa i iscrtavanje grafikona
		        var ctx = document.getElementById('grafPodaciPrikaz').getContext('2d');
		        new Chart(ctx, config);
		    } else {
		        console.error('Zahtev nije uspeo!');
		    }
		};
		
		xhr.onerror = function() {
		    console.error('Došlo je do greške prilikom zahteva.');
		};
		
		xhr.send();
	    document.getElementById('graphDiv').style.display = 'block'
	});	
//////////


document.getElementById('grafModel').addEventListener('click', function(event) {    
    event.preventDefault();
    
    var container = document.getElementById('graphDiv');
    container.innerHTML = '';
    var chartDiv = document.createElement('div');
    chartDiv.style.width = '700px';
    chartDiv.style.height = '400px';
    container.appendChild(chartDiv);
    
    var myChart1 = echarts.init(chartDiv);
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'ServeletSvmGrafModel', true);    // moze i svmGrafModel.jsp
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var odgovor = JSON.parse(xhr.responseText);
            var matrica1 = odgovor.matrica1;
            var matrica2 = odgovor.matrica2;
            var matrica01 = odgovor.matrica3;
            var matrica02 = odgovor.matrica4;
            
            function convertMatrixToSeriesData(matrix, color) {
                return matrix.map(function(point) {
                    return {
                        value: [point[0], point[1]],
                        itemStyle: { color: color }
                    };
                });
            }
            
            var option = {
                tooltip: {},
                legend: {
                    data: ['Klasa 1', 'Klasa 2', 'Oblast Klase 1', 'Oblast Klase 2']
                },
                xAxis: {
                    min: 'dataMin',
                    max: 'dataMax',
			         axisLabel: {
			            formatter: function(value) {
			                return value.toFixed(3); // Zaokruživanje na tri decimale
			            }
			        }                  
                },
                yAxis: {
                    min: 'dataMin',
                    max: 'dataMax',
			        axisLabel: {
			            formatter: function(value) {
			                return value.toFixed(3); // Zaokruživanje na tri decimale
			            }
			        }                    
                },
                series: [{
		            name: 'Oblast Klase 1',
		            type: 'scatter',		            
		            //data: convertMatrixToSeriesData(matrica01, 'yellow'),
		            data: convertMatrixToSeriesData(matrica01, 'yellow'),
		            symbolSize: 3, // Simboli neće biti vidljivi
		            large: true, // Optimizacija za veliki set podataka
		            areaStyle: {
						//color: 'rgba(255, 255, 0, 0.9)',							
						origin:'start',
						color: 'yellow',	
						opacity: 0.3                
		            },
		            z:0 
                }, {
					///
		            name: 'Oblast Klase 2',
		            type: 'scatter',
		            data: convertMatrixToSeriesData(matrica02, 'red'),
		            symbolSize: 3, // Simboli neće biti vidljivi
		            large: true, // Optimizacija za veliki set podataka
		            areaStyle: {
		                //color: 'rgba(0, 128, 0, 0.9)'
		                color: 'red',
		                opacity: 0.3 
		           },
		            z:0                					
					///
                }, {
                    ///
                    name: 'Klasa 1',
                    type: 'scatter',
                    data: convertMatrixToSeriesData(matrica1, 'red'),
                    symbolSize: 5.0,
                    z:1
                    ///
                }, {
					///
                    name: 'Klasa 2',
                    type: 'scatter',
                    data: convertMatrixToSeriesData(matrica2, 'blue'),
                    symbolSize: 5.0,
                    z:1				
					///
                }],
                animation: false
            };          
            myChart1.setOption(option, { notMerge: true });            
            //myChart1.setOption(option);
            document.getElementById('graphDiv').style.display = 'block';
        }
    };
    xhr.send();               
});


/*
function sortirajPodatke(data) {
    // Pretpostavljamo da su tačke u obliku {x: number, y: number}
    return data.sort((a, b) => a.x - b.x);
}

*/

document.getElementById('grafTest').addEventListener('click', function(event) {    
    event.preventDefault();
    
    var container = document.getElementById('graphDiv');
    container.style.width = '700px';
    container.style.height = '450px';
    container.innerHTML = '';
    var chartDiv = document.createElement('div');
    chartDiv.style.width = '700px';
    chartDiv.style.height = '400px';
    container.appendChild(chartDiv);
    
    var myChart = echarts.init(chartDiv);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'ServeletSvmGrafTest', true);    //svmGrafTest.jsp
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var odgovor = JSON.parse(xhr.responseText);
            var matrica1 = odgovor.matrica1;
            var matrica2 = odgovor.matrica2;
            var matrica01 = odgovor.matrica3;
            var matrica02 = odgovor.matrica4;
            
            function convertMatrixToSeriesData(matrix, color) {
                return matrix.map(function(point) {
                    return {
                        value: [point[0], point[1]],
                        itemStyle: { color: color }
                    };
                });
            }
            
            var option = {
                tooltip: {},
                legend: {
                    data: ['Klasa 1', 'Klasa 2', 'Oblast Klase 1', 'Oblast Klase 2']
                },
                xAxis: {
                    min: 'dataMin',
                    max: 'dataMax',
			         axisLabel: {
			            formatter: function(value) {
			                return value.toFixed(3); // Zaokruživanje na tri decimale
			            }
			        }                  
                },
                yAxis: {
                    min: 'dataMin',
                    max: 'dataMax',
			        axisLabel: {
			            formatter: function(value) {
			                return value.toFixed(3); // Zaokruživanje na tri decimale
			            }
			        }                    
                },
                series: [{
		            name: 'Oblast Klase 1',
		            type: 'scatter',
		            data: convertMatrixToSeriesData(matrica01, 'green'),
		            symbolSize: 3, // Simboli neće biti vidljivi
		            large: true, // Optimizacija za veliki set podataka
		            areaStyle: {
		                color: 'green',
		                opacity: 0.9 // Prozirnost oblasti
		            },
		            z:1 
                }, {
					///
		            name: 'Oblast Klase 2',
		            type: 'scatter',
		            data: convertMatrixToSeriesData(matrica02, 'yellow'),
		            symbolSize: 3, // Simboli neće biti vidljivi
		            large: true, // Optimizacija za veliki set podataka
		            areaStyle: {
		                color: 'yellow',
		                opacity: 0.9 // Prozirnost oblasti
		           },
		            z:1                					
					///
                }, {
                    ///
                    name: 'Klasa 1',
                    type: 'scatter',
                    data: convertMatrixToSeriesData(matrica1, 'red'),
                    symbolSize: 5.0
                    ///
                }, {
					///
                    name: 'Klasa 2',
                    type: 'scatter',
                    data: convertMatrixToSeriesData(matrica2, 'blue'),
                    symbolSize: 5.0					
					///
                }],
                animation: false
            };
 			// Koristimo setOption da nacrtamo grafikon sa novim podacima
			// Drugi argument 'true' znači da se prethodni grafikon potpuno zamenjuje           
            myChart.setOption(option, { notMerge: true });
           
            //myChart.setOption(option);
            document.getElementById('graphDiv').style.display = 'block';
        }
    };
    xhr.send();               
});
////
	
	document.addEventListener('DOMContentLoaded', function() {
	    var svm_type = document.getElementById('svm_type');
	    var nu = document.getElementById('nu');
	    var cost = document.getElementById('cost');
	
	    function updateVisibility() {
	        var svm_type1 = svm_type.value;
	        if (svm_type1 === '0' || svm_type1 === '3' ) {
	            nu.parentElement.style.display = 'none';
	        } else {
	            nu.parentElement.style.display = 'block';
	        }
	        if (svm_type1 === '1' || svm_type1 === '2' ) {
	            cost.parentElement.style.display = 'none';
	        } else {
	            cost.parentElement.style.display = 'block';
	        }	        
	    }
	
	    svm_type.addEventListener('change', updateVisibility);
	    // Inicijalno ažuriranje vidljivosti prilikom učitavanja stranice
	    updateVisibility();
	});		
	
    document.getElementById('useModel').addEventListener('click', function() {
		var iframe1 = document.createElement('iframe');
		iframe1.id = 'iframeUse';
	    iframe1.style.width = '700px';
	    iframe1.style.height = '100px';
	    iframe1.src = 'useModel.html'; 
	    		
        var useDiv = document.getElementById('useDiv');  
        // Očisti prethodni sadržaj kontejnera ako je potrebno
        useDiv.innerHTML = '';
        useDiv.style.display = 'block'; // Prikazuje kontejner
        useDiv.appendChild(iframe1);     
        //var container = document.getElementById('canvas-container');
        //container.appendChild(useDiv);  
    });	

	window.addEventListener('message', function(event) {
	    
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeUse');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});     
    
//////////
	document.getElementById('cachesize').addEventListener('input', function() {
		document.getElementById('cachesizeOutput').textContent = this.value;
	});    
///////////
	// primam rezultat od useModel.html
	window.addEventListener('message', function(event) {
	    // Možete dodati proveru event.origin ovde za dodatnu sigurnost
	    if (event.data.key === 'vred') {
	        //alert("Nova vrednost: " + event.data.value);
	        document.getElementById('textInput').value += "\n"+event.data.value;
	    }
	}, false);    
    
});	
  			