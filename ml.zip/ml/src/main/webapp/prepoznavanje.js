const canvas = document.getElementById('drawingCanvas');
const ctx = canvas.getContext('2d', { willReadFrequently: true });
const colorPicker = document.getElementById('colorPicker');
const lineWidth = document.getElementById('lineWidth');
const zoomButton = document.getElementById('zoomButton');
const convertButton = document.getElementById('convertButton');
const deleteButton = document.getElementById('deleteButton');
const matrixOutput = document.getElementById('matrixOutput');

let isDrawing = false;
let originalImage = null;
let zoomed = false;

canvas.width = 300;  // Veća rezolucija za detaljnije crtanje
canvas.height = 300;

canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);
zoomButton.addEventListener('click', zoomDrawing);
convertButton.addEventListener('click', convertToMatrix);
deleteButton.addEventListener('click', clearCanvas);

const podaci = [];
var nizUlaza = [];


/*
function startDrawing(e) {
    isDrawing = true;
    draw(e);
}
*/
function startDrawing(e) {
    isDrawing = true;
    const mousePos = getMousePos(canvas, e);
    ctx.moveTo(mousePos.x, mousePos.y);
    draw(e);
}
function getMousePos(canvas, evt) {
    var rect = canvas.getBoundingClientRect();
    return {
        x: evt.clientX - rect.left,
        y: evt.clientY - rect.top
    };
}
function draw(e) {
    if (!isDrawing) return;
    const mousePos = getMousePos(canvas, e);

    ctx.lineWidth = lineWidth.value;
    ctx.lineCap = 'round';
    ctx.strokeStyle = colorPicker.value;

    ctx.lineTo(mousePos.x, mousePos.y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(mousePos.x, mousePos.y);
}


function stopDrawing() {
    isDrawing = false;
    ctx.beginPath();
    if (!zoomed) {
        originalImage = ctx.getImageData(0, 0, canvas.width, canvas.height);
    }
}

function zoomDrawing() {
    if (!originalImage) return;
    const bounds = findDrawingBounds(originalImage);
    if (!bounds) return;

    const { x, y, width, height } = bounds;

    // Kreiranje privremenog canvas-a za izvlačenje područja crteža
    const tempCanvas = document.createElement('canvas');
    const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
    tempCanvas.width = width;
    tempCanvas.height = height;

    // Izvlačenje područja crteža
    tempCtx.drawImage(canvas, x, y, width, height, 0, 0, width, height);

    // Skaliranje i centriranje izvučenog područja na originalnom canvas-u
    const scale = Math.min(canvas.width / width, canvas.height / height);
    const scaledWidth = width * scale;
    const scaledHeight = height * scale;
    const dx = (canvas.width - scaledWidth) / 2;
    const dy = (canvas.height - scaledHeight) / 2;

    // Čišćenje originalnog canvas-a i iscrtavanje skaliranog crteža
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(tempCanvas, 0, 0, width, height, dx, dy, scaledWidth, scaledHeight);

    zoomed = true;
}

function convertToMatrix() {
    if (!zoomed) {
        alert("Prvo zumiraj sliku.");
        return;
    }

    const matrixSize = 7;
    const cellWidth = canvas.width / matrixSize;
    const cellHeight = canvas.height / matrixSize;
    const matrix = [];
    for (let y = 0; y < matrixSize; y++) {
        const row = [];
        for (let x = 0; x < matrixSize; x++) {
            const cell = ctx.getImageData(x * cellWidth, y * cellHeight, cellWidth, cellHeight);
            row.push(isCellFilled(cell) ? 1.0 : 0.0);
        }
        matrix.push(row);
    }
        
    matrixOutput.textContent = matrix.map(row => row.join(' ')).join('\n');
    niz = matrix.reduce((akumulator, red) => akumulator.concat(red), []);
    nizUlaza = matrix.reduce((akumulator, red) => akumulator.concat(red), []);
     
    let unosKorisnika = prompt("Naziv oblika1:", "");
	if (unosKorisnika !== null) {
	    niz.push(unosKorisnika);
	} else {
	    console.log("Korisnik je kliknuo na Cancel.");
	}      
    
    podaci.push(niz);
    //alert("podaci: " + podaci);
}



function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    originalImage = null;
    zoomed = false;
}

function isCellFilled(cellData) {
    for (let i = 0; i < cellData.data.length; i += 4) {
        if (cellData.data[i + 3] > 0) {
            return true;
        }
    }
    return false;
}

function findDrawingBounds(imageData) {
    const data = imageData.data;
    let minX = imageData.width;
    let minY = imageData.height;
    let maxX = 0;
    let maxY = 0;
    for (let y = 0; y < imageData.height; y++) {
        for (let x = 0; x < imageData.width; x++) {
            const alpha = data[(y * imageData.width + x) * 4 + 3];
            if (alpha > 0) {
                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x);
                minY = Math.min(minY, y);
                maxY = Math.max(maxY, y);
            }
        }
    }
    if (minX < maxX && minY < maxY) {
        return { x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1 };
    }
    return null;
}

document.getElementById('addButton').addEventListener('click', function(event) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "ServeletDataSetPrepoznavanje", true);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
			alert("Podaci su ucitani!");
            console.log("Matrica je poslata na server.");
        }
    };
    xhr.send(JSON.stringify({ podaci: podaci }));	
});	

document.getElementById('prepoznajButton').addEventListener('click', function(event) {
	
/// convertToMatrix
   if (!zoomed) {
        alert("Prvo zumiraj sliku.");
        return;
    }

    const matrixSize = 7;
    const cellWidth = canvas.width / matrixSize;
    const cellHeight = canvas.height / matrixSize;
    const matrix = [];
    for (let y = 0; y < matrixSize; y++) {
        const row = [];
        for (let x = 0; x < matrixSize; x++) {
            const cell = ctx.getImageData(x * cellWidth, y * cellHeight, cellWidth, cellHeight);
            row.push(isCellFilled(cell) ? 1.0 : 0.0);
        }
        matrix.push(row);
    }
        
    matrixOutput.textContent = matrix.map(row => row.join(' ')).join('\n');
    niz = matrix.reduce((akumulator, red) => akumulator.concat(red), []);
    nizUlaza = matrix.reduce((akumulator, red) => akumulator.concat(red), []);
             
////////
    var xhr1 = new XMLHttpRequest();
    xhr1.open("POST", "ServeletPrepoznaj", true);
    xhr1.setRequestHeader("Content-Type", "application/json");

    xhr1.onreadystatechange = function() {
        if (xhr1.readyState == 4 && xhr1.status == 200) {
            console.log("Matrica je poslata na server.");
            //alert("PREPOZNATO JE:" + xhr1.responseText);
            document.getElementById('matrixOutput').textContent = "PREPOZNATO JE:" + xhr1.responseText;
        }
    };
    xhr1.send(JSON.stringify({nizUlaza: nizUlaza }));	   
});	
