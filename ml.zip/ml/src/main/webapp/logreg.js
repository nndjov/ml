document.addEventListener('DOMContentLoaded', (event) => {   
	 
    document.getElementById('dataset').addEventListener('click', function() {		
			var iframe = document.getElementById('iframeData');					
            //var iframe = document.createElement('iframe');
            iframe.src = 'excel.html'; // 
            iframe.style.height = '100';
            iframe.style.width = '700';				
            iframe.src = 'excel.html'; // 

            var container = document.getElementById('dataDiv');  

            container.innerHTML = '';
            container.style.display = 'block'; // Prikazuje kontejner
            container.appendChild(iframe); // Dodaje iframe u kontejner           
    });
    
	window.addEventListener('message', function(event) {
	    // Ovde možete dodati provere za `event.origin` radi sigurnosti
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeData');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});

	document.getElementById('grafPodaci').addEventListener('click', function(event) {	
        event.preventDefault()	
	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv);  	    
	          
		var xhr = new XMLHttpRequest();
		xhr.open('GET', 'ServeletGrafLogReg', true);		
		xhr.onload = function() {
		    if (xhr.status >= 200 && xhr.status < 300) {
		        // Parsiranje odgovora u JSON formatu
		        const podaci = JSON.parse(xhr.responseText);
		
		        // Ekstrakcija podataka za crtanje grafikona
		        const podaciZaGrafikon = podaci.map(function(d) {
		            return { x: d[0], y: d[1], klasa: d[2] };
		        });
		
		        // Podela podataka na dve klase
		        const klasa1 = podaciZaGrafikon.filter(p => p.klasa === 1);
		        const klasa0 = podaciZaGrafikon.filter(p => p.klasa === 0);
		
		        // Konfiguracija za Chart.js
		        const config = {
		            type: 'scatter',
		            data: {
		                datasets: [{
		                    label: 'Klasa 1',
		                    data: klasa1,
		                    backgroundColor: 'rgba(255, 99, 132, 1)',
		                }, {
		                    label: 'Klasa 0',
		                    data: klasa0,
		                    backgroundColor: 'rgba(54, 162, 235, 1)',
		                }]
		            },
		            options: {
		                scales: {
		                    x: {
		                        title: {
		                            display: true,
		                            text: 'X1'
		                        }
		                    },
		                    y: {
		                        title: {
		                            display: true,
		                            text: 'X2'
		                        }
		                    }
		                }
		            }
		        };
		
		        // Dobavljanje canvas elementa i iscrtavanje grafikona
		        var ctx = document.getElementById('grafPodaciPrikaz').getContext('2d');
		        new Chart(ctx, config);
		    } else {
		        console.error('Zahtev nije uspeo!');
		    }
		};
		
		xhr.onerror = function() {
		    console.error('Došlo je do greške prilikom zahteva.');
		};
		
		xhr.send();
	    document.getElementById('graphDiv').style.display = 'block'
	});	
//////////
   document.getElementById('treningLogReg').addEventListener('click', function() {				
		var numEpoch = document.getElementById('numEpoch').value;
		var learningRate = document.getElementById('learningRate').value;
		var lambda = document.getElementById('lambda').value;	
		var reg_type = document.querySelector('input[name="reg_type"]:checked').value;	
					
		var podaciZaSlanje = {
		    numEpoch: numEpoch,
		    learningRate: learningRate,
		    lambda: lambda,
		    reg_type: reg_type		        		    
	    };
		
		console.log(podaciZaSlanje);
					
		var jsonPodaci = JSON.stringify(podaciZaSlanje);	
		//var jsonPodaci = prepareDataForAjax(podaciZaSlanje);
						
		//AJAX poziv
		var xhr = new XMLHttpRequest();
		xhr.open('POST', 'ServeletTreningLogReg', true); 
		xhr.setRequestHeader('Content-Type', 'application/json');
	
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
				document.getElementById('textInput').value += "\n\n"+xhr.responseText;
			}
		};
		xhr.send(jsonPodaci);         
    });

	document.getElementById('grafGreske').addEventListener('click', function(event) {	
        event.preventDefault()	
        
	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv); 
	            
		///trazim niz od nizGreske.jsp
	    var xhr = new XMLHttpRequest();
	    xhr.open('GET', 'ServeletGrafLogGreske', true);	
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && xhr.status == 200) {
	            var nizGreske1 = JSON.parse(xhr.responseText);
				var canvas = document.getElementById('grafPodaciPrikaz');
				var ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   
				window.grafGreske = new Chart(ctx, {	
			        type: 'line', // Tip grafa, može biti 'bar', 'line' itd.
			        data: {
			            labels: nizGreske1.map((_, i) => i + 1), // Oznake za X osu
			            datasets: [{
			                label: 'ERROR',
			                data: nizGreske1, // Vaši podaci
			                backgroundColor: 'rgba(255, 99, 132, 0.2)',
			                borderColor: 'rgba(255, 99, 132, 1)',
			                borderWidth: 1,
			                pointRadius: 1
			            }]
			        },
			        options: {
						responsive: false,
			            scales: {
			                y: 	{
			                    beginAtZero: false
			                }
			            }
			        }
			    });            
			}
    	};
    	xhr.send();   
	    document.getElementById('grafPodaciPrikaz').style.display = 'block'
	});	
	
//////////

   document.getElementById('useModelLogReg').addEventListener('click', function(event) {	
        event.preventDefault()		   
	   alert("CAO");
		var iframe1 = document.createElement('iframe');
		iframe1.id = 'iframeUse';
	    iframe1.style.width = '700px';
	    iframe1.style.height = '100px';
	    iframe1.src = 'useModelLogReg.html'; 
	    		
        var useDiv = document.getElementById('useDiv');  
        // Očisti prethodni sadržaj kontejnera ako je potrebno
        useDiv.innerHTML = '';
        useDiv.style.display = 'block'; // Prikazuje kontejner
        useDiv.appendChild(iframe1);     
        //var container = document.getElementById('canvas-container');
        //container.appendChild(useDiv);  
    });	

	window.addEventListener('message', function(event) {	    
	    if (event.data.action === 'changeDimensions') {
	        var iframe = document.getElementById('iframeUse');
	        if (iframe) {
	            iframe.style.height = event.data.newHeight;
	            iframe.style.width = event.data.newWidth;
	        }
	    }
	});     
    
//////////
	//document.getElementById('cachesize').addEventListener('input', function() {
	//	document.getElementById('cachesizeOutput').textContent = this.value;
	//});    
///////////
	// primam rezultat od useModel.html
	window.addEventListener('message', function(event) {
	    // Možete dodati proveru event.origin ovde za dodatnu sigurnost
	    if (event.data.key === 'vred') {
	        //alert("Nova vrednost: " + event.data.value);
	        document.getElementById('textInput').value += "\n"+event.data.value;
	    }
	}, false); 
//////////    

	document.getElementById('regresijaGraf').addEventListener('click', function(event) {	
        event.preventDefault()	
        
	    var container = document.getElementById('graphDiv');
	    container.innerHTML = '';
	    var chartDiv = document.createElement('div');
	    chartDiv.style.width = '700px';
	    chartDiv.style.height = '400px';
	    
	    var chartCanvas = document.createElement('canvas');
	    chartCanvas.id = 'grafPodaciPrikaz';
	    chartCanvas.style.width = '700px';
	    chartCanvas.style.height = '400px';	  
	    chartDiv.appendChild(chartCanvas);  
	    container.appendChild(chartDiv);         
//////////////////
       var xhr = new XMLHttpRequest();
       var ctx;
        xhr.open('GET', 'ServeletGrafLogLinija', true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Dobijanje podataka iz odgovora
                var response = JSON.parse(xhr.responseText);
                var matricaUlaza = response.matricaUlaza;
                var matricaIzlaza = response.matricaIzlaza;  
                var koeficijenti  = response.koeficijenti;          
			    //var matrica = [];			
			    // Spajamo matrice
			    //for (var i = 0; i < matricaUlaza.length; i++) {
			    //    matrica.push([matricaUlaza[i][0], matricaUlaza[i][1]]);
			    //}                
                // Iscrtavanje podataka u grafikonu

				var canvas = document.getElementById('grafPodaciPrikaz');
				ctx = canvas.getContext('2d', { willReadFrequently: true });	    
				if (window.grafGreske && typeof window.grafGreske.destroy === 'function') {
				    window.grafGreske.destroy();
				}   
        		var t0 = koeficijenti[0];
       			var t1 = koeficijenti[1];
       			var t2 = koeficijenti[2];
       			var b0 = -t0/t2;
       			var b1 = -t1/t2;
       			//var teta = koeficijenti;
////////////       			
// Kreiranje podataka za prikaz na grafikonu
var data = {
    datasets: [{
        label: 'Klasa 0',
        backgroundColor: 'rgba(255, 99, 132, 0.5)', // Crvena boja za klasu 0
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        data: [] // Podaci za klasu 0
    }, {
        label: 'Klasa 1',
        backgroundColor: 'rgba(54, 162, 235, 0.5)', // Plava boja za klasu 1
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
        data: [] // Podaci za klasu 1
    }]
};

// Dodavanje podataka iz matrice ulaza u odgovarajuće kategorije
// Pretpostavka je da matrica ulaza ima oblik [[x1_1, x2_1], [x1_2, x2_2], ...]
for (var i = 0; i < matricaUlaza.length; i++) {
    var klasa = matricaIzlaza[i][0]; // Klasa za trenutnu instancu
    data.datasets[klasa].data.push({ x: matricaUlaza[i][0], y: matricaUlaza[i][1] });
}

// ovo je novo
// Dobijanje minimuma i maksimuma samo za prvu kolonu matriceUlaza (x1)
var minX = Math.min.apply(null, matricaUlaza.map(function(arr) { return arr[0]; }));
var maxX = Math.max.apply(null, matricaUlaza.map(function(arr) { return arr[0]; }));
var minY = b0 + b1 * minX;
var maxY = b0 + b1 * maxX;

// Dodavanje linije u podatke za grafikon
data.datasets.push({			        
	type: 'line',
	label: 'Logistic Regression',
	data: [{ x: minX, y: minY }, { x: maxX, y: maxY }],
//	data: [{ x: Math.min(...matricaUlaza) , y: b0 + b1 * Math.min(...matricaUlaza) },
//		   { x: Math.max(...matricaUlaza) , y: b0 + b1 * Math.max(...matricaUlaza) }],
	borderColor: 'red',
	borderWidth: 5,
	fill: false,
				         	
});

// Konfiguracija grafikona
var options = {
    scales: {
        xAxes: [{
            type: 'linear',
            position: 'bottom'
        }],
        yAxes: [{
            type: 'linear',
            position: 'left'
        }]
    }
};

// Kreiranje grafikona


//var myChart = new Chart(ctx, {
window.grafGreske = new Chart(ctx,{	
    type: 'scatter', // Tip grafikona je raspored tačaka
    data: data,
    options: options
});	           
//////////
            }          
        };

        xhr.send();        
    });    	

   	
});       